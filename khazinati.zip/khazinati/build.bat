@echo off
chcp 65001 >nul
echo === بناء تطبيق خزنتي ===
if not exist android (
  call flutter create --platforms=android --org com.khazinati --project-name khazinati .
  if errorlevel 1 goto :error
  call flutter pub get
  call dart run tool/setup_android.dart
  if errorlevel 1 goto :error
  call dart run flutter_launcher_icons
) else (
  call flutter pub get
)
call flutter build apk --release
if errorlevel 1 goto :error
echo.
echo تم! الملف موجود في:
echo build\app\outputs\flutter-apk\app-release.apk
explorer build\app\outputs\flutter-apk
pause
exit /b 0

:error
echo حدث خطأ أثناء البناء
pause
exit /b 1
