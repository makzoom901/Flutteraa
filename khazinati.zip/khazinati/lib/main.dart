import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'data/db.dart';
import 'screens/home_screen.dart';
import 'screens/lock_screen.dart';
import 'services/app_lock.dart';
import 'services/icon_service.dart';
import 'services/notification_service.dart';
import 'services/theme_controller.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

  await Db.init();
  ThemeController.load();
  await NotificationService.init();

  runApp(const KhazinatiApp());

  // في الخلفية: إعادة جدولة التذكيرات وجلب أيقونات المواقع الناقصة
  NotificationService.rescheduleAll();
  IconService.refreshMissing();
}

class KhazinatiApp extends StatefulWidget {
  const KhazinatiApp({super.key});

  @override
  State<KhazinatiApp> createState() => _KhazinatiAppState();
}

class _KhazinatiAppState extends State<KhazinatiApp>
    with WidgetsBindingObserver {
  DateTime? _backgroundAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  /// قفل تلقائي عند الرجوع للتطبيق بعد بقائه في الخلفية
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden) {
      _backgroundAt ??= DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final t = _backgroundAt;
      _backgroundAt = null;
      if (t != null &&
          DateTime.now().difference(t) >= AppLock.backgroundTimeout) {
        AppLock.lock();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'خزنتي',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const HomeScreen(),
      builder: (context, child) {
        return ValueListenableBuilder<bool>(
          valueListenable: AppLock.locked,
          builder: (context, locked, _) {
            return Stack(
              children: [
                // المحتوى يبقى في مكانه لكن مخفي تماماً أثناء القفل
                Offstage(
                  offstage: locked,
                  child: TickerMode(
                    enabled: !locked,
                    child: child ?? const SizedBox.shrink(),
                  ),
                ),
                if (locked) const Positioned.fill(child: LockScreen()),
              ],
            );
          },
        );
      },
    );
  }
}
