import 'package:flutter/material.dart';

String newId() => DateTime.now().microsecondsSinceEpoch.toString();

DateTime? _date(dynamic v) =>
    v is int ? DateTime.fromMillisecondsSinceEpoch(v) : null;

/// تصنيف (شخصي، عمل، ...) مع لون
class ItemCategory {
  final String id;
  String name;
  int color;

  ItemCategory({required this.id, required this.name, required this.color});

  Color get colorValue => Color(color);

  Map<String, dynamic> toMap() => {'id': id, 'name': name, 'color': color};

  factory ItemCategory.fromMap(Map m) => ItemCategory(
        id: m['id'] as String,
        name: (m['name'] ?? '') as String,
        color: (m['color'] ?? 0xFF6B7280) as int,
      );
}

/// كلمة مرور / حساب
class PasswordItem {
  final String id;
  String title;
  String username;
  String password;
  String url;
  String note;
  String? categoryId;
  DateTime updatedAt;
  String? icon; // شعار الموقع (base64)
  String? iconDomain;

  PasswordItem({
    required this.id,
    this.title = '',
    this.username = '',
    this.password = '',
    this.url = '',
    this.note = '',
    this.categoryId,
    DateTime? updatedAt,
    this.icon,
    this.iconDomain,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'username': username,
        'password': password,
        'url': url,
        'note': note,
        'categoryId': categoryId,
        'updatedAt': updatedAt.millisecondsSinceEpoch,
        'icon': icon,
        'iconDomain': iconDomain,
      };

  factory PasswordItem.fromMap(Map m) => PasswordItem(
        id: m['id'] as String,
        title: (m['title'] ?? '') as String,
        username: (m['username'] ?? '') as String,
        password: (m['password'] ?? '') as String,
        url: (m['url'] ?? '') as String,
        note: (m['note'] ?? '') as String,
        categoryId: m['categoryId'] as String?,
        updatedAt: _date(m['updatedAt']),
        icon: m['icon'] as String?,
        iconDomain: m['iconDomain'] as String?,
      );

  bool matches(String q) =>
      title.toLowerCase().contains(q) ||
      username.toLowerCase().contains(q) ||
      url.toLowerCase().contains(q) ||
      note.toLowerCase().contains(q);
}

/// ملاحظة
class NoteItem {
  final String id;
  String title;
  String content;
  String? categoryId;
  DateTime updatedAt;

  NoteItem({
    required this.id,
    this.title = '',
    this.content = '',
    this.categoryId,
    DateTime? updatedAt,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'content': content,
        'categoryId': categoryId,
        'updatedAt': updatedAt.millisecondsSinceEpoch,
      };

  factory NoteItem.fromMap(Map m) => NoteItem(
        id: m['id'] as String,
        title: (m['title'] ?? '') as String,
        content: (m['content'] ?? '') as String,
        categoryId: m['categoryId'] as String?,
        updatedAt: _date(m['updatedAt']),
      );

  bool matches(String q) =>
      title.toLowerCase().contains(q) || content.toLowerCase().contains(q);
}

/// موقع مفضل
class BookmarkItem {
  final String id;
  String title;
  String url;
  String note;
  String? categoryId;
  DateTime updatedAt;
  String? icon;
  String? iconDomain;

  BookmarkItem({
    required this.id,
    this.title = '',
    this.url = '',
    this.note = '',
    this.categoryId,
    DateTime? updatedAt,
    this.icon,
    this.iconDomain,
  }) : updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'url': url,
        'note': note,
        'categoryId': categoryId,
        'updatedAt': updatedAt.millisecondsSinceEpoch,
        'icon': icon,
        'iconDomain': iconDomain,
      };

  factory BookmarkItem.fromMap(Map m) => BookmarkItem(
        id: m['id'] as String,
        title: (m['title'] ?? '') as String,
        url: (m['url'] ?? '') as String,
        note: (m['note'] ?? '') as String,
        categoryId: m['categoryId'] as String?,
        updatedAt: _date(m['updatedAt']),
        icon: m['icon'] as String?,
        iconDomain: m['iconDomain'] as String?,
      );

  bool matches(String q) =>
      title.toLowerCase().contains(q) ||
      url.toLowerCase().contains(q) ||
      note.toLowerCase().contains(q);
}

/// مدة الاشتراك
enum SubPeriod { monthly, quarterly, yearly, custom }

extension SubPeriodX on SubPeriod {
  String get label {
    switch (this) {
      case SubPeriod.monthly:
        return 'شهري';
      case SubPeriod.quarterly:
        return '3 أشهر';
      case SubPeriod.yearly:
        return 'سنوي';
      case SubPeriod.custom:
        return 'مدة مخصصة';
    }
  }

  /// عدد الأشهر (0 للمخصص)
  int get months {
    switch (this) {
      case SubPeriod.monthly:
        return 1;
      case SubPeriod.quarterly:
        return 3;
      case SubPeriod.yearly:
        return 12;
      case SubPeriod.custom:
        return 0;
    }
  }
}

DateTime addMonths(DateTime d, int months) {
  final y = d.year + ((d.month - 1 + months) ~/ 12);
  final m = ((d.month - 1 + months) % 12) + 1;
  final lastDay = DateTime(y, m + 1, 0).day;
  return DateTime(y, m, d.day > lastDay ? lastDay : d.day);
}

/// اشتراك في موقع أو خدمة
class SubscriptionItem {
  final String id;
  String name;
  String url;
  String price;
  DateTime startDate;
  DateTime endDate;
  SubPeriod period;
  int remindDays; // التذكير قبل الانتهاء بكم يوم
  String note;
  String? categoryId;
  String? icon;
  String? iconDomain;

  SubscriptionItem({
    required this.id,
    this.name = '',
    this.url = '',
    this.price = '',
    required this.startDate,
    required this.endDate,
    this.period = SubPeriod.monthly,
    this.remindDays = 3,
    this.note = '',
    this.categoryId,
    this.icon,
    this.iconDomain,
  });

  /// الأيام المتبقية (سالب = منتهي)
  int get daysLeft {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final end = DateTime(endDate.year, endDate.month, endDate.day);
    return end.difference(today).inDays;
  }

  bool get isExpired => daysLeft < 0;
  bool get isSoon => !isExpired && daysLeft <= (remindDays < 7 ? 7 : remindDays);

  /// تجديد: نقل تاريخ البداية والنهاية لفترة جديدة
  void renew() {
    if (period == SubPeriod.custom) {
      final len = endDate.difference(startDate);
      startDate = endDate;
      endDate = endDate.add(len.inDays > 0 ? len : const Duration(days: 30));
    } else {
      startDate = endDate;
      endDate = addMonths(endDate, period.months);
    }
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'url': url,
        'price': price,
        'startDate': startDate.millisecondsSinceEpoch,
        'endDate': endDate.millisecondsSinceEpoch,
        'period': period.index,
        'remindDays': remindDays,
        'note': note,
        'categoryId': categoryId,
        'icon': icon,
        'iconDomain': iconDomain,
      };

  factory SubscriptionItem.fromMap(Map m) => SubscriptionItem(
        id: m['id'] as String,
        name: (m['name'] ?? '') as String,
        url: (m['url'] ?? '') as String,
        price: (m['price'] ?? '') as String,
        startDate: _date(m['startDate']) ?? DateTime.now(),
        endDate: _date(m['endDate']) ?? DateTime.now(),
        period: SubPeriod.values[(m['period'] ?? 0) as int],
        remindDays: (m['remindDays'] ?? 3) as int,
        note: (m['note'] ?? '') as String,
        categoryId: m['categoryId'] as String?,
        icon: m['icon'] as String?,
        iconDomain: m['iconDomain'] as String?,
      );

  bool matches(String q) =>
      name.toLowerCase().contains(q) ||
      url.toLowerCase().contains(q) ||
      note.toLowerCase().contains(q);
}
