import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'models.dart';

/// التخزين الآمن الخاص بالنظام (Android Keystore)
const secureStorage = FlutterSecureStorage(
  aOptions: AndroidOptions(encryptedSharedPreferences: true),
);

/// قاعدة البيانات: كل الصناديق مشفّرة بـ AES-256
/// ومفتاح التشفير محفوظ داخل Android Keystore.
class Db {
  static late Box categories;
  static late Box passwords;
  static late Box notes;
  static late Box bookmarks;
  static late Box subs;
  static late Box settings;

  static const _keyName = 'khazinati_db_key_v1';

  static Future<void> init() async {
    await Hive.initFlutter();

    var encoded = await secureStorage.read(key: _keyName);
    if (encoded == null) {
      final key = Hive.generateSecureKey();
      encoded = base64UrlEncode(key);
      await secureStorage.write(key: _keyName, value: encoded);
    }
    final cipher = HiveAesCipher(base64Url.decode(encoded));

    categories = await Hive.openBox('categories', encryptionCipher: cipher);
    passwords = await Hive.openBox('passwords', encryptionCipher: cipher);
    notes = await Hive.openBox('notes', encryptionCipher: cipher);
    bookmarks = await Hive.openBox('bookmarks', encryptionCipher: cipher);
    subs = await Hive.openBox('subscriptions', encryptionCipher: cipher);
    settings = await Hive.openBox('settings', encryptionCipher: cipher);

    if (categories.isEmpty) {
      await saveCategory(ItemCategory(id: '0001', name: 'شخصي', color: 0xFF1E5EFF));
      await saveCategory(ItemCategory(id: '0002', name: 'عمل', color: 0xFFF97316));
    }
  }

  // ---------------- التصنيفات ----------------
  static List<ItemCategory> allCategories() =>
      categories.values.map((e) => ItemCategory.fromMap(e as Map)).toList();

  static ItemCategory? category(String? id) {
    if (id == null) return null;
    final m = categories.get(id);
    return m is Map ? ItemCategory.fromMap(m) : null;
  }

  static Future<void> saveCategory(ItemCategory c) => categories.put(c.id, c.toMap());

  /// حذف تصنيف: العناصر المرتبطة به تصبح "بدون تصنيف"
  static Future<void> deleteCategory(String id) async {
    await categories.delete(id);
    for (final box in [passwords, notes, bookmarks, subs]) {
      for (final key in box.keys.toList()) {
        final raw = box.get(key);
        if (raw is Map && raw['categoryId'] == id) {
          final m = Map<String, dynamic>.from(raw);
          m['categoryId'] = null;
          await box.put(key, m);
        }
      }
    }
  }

  static int countInCategory(String id) {
    var n = 0;
    for (final box in [passwords, notes, bookmarks, subs]) {
      for (final v in box.values) {
        if (v is Map && v['categoryId'] == id) n++;
      }
    }
    return n;
  }

  // ---------------- كلمات المرور ----------------
  static List<PasswordItem> allPasswords() {
    final list =
        passwords.values.map((e) => PasswordItem.fromMap(e as Map)).toList();
    list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return list;
  }

  static Future<void> savePassword(PasswordItem p) {
    p.updatedAt = DateTime.now();
    return passwords.put(p.id, p.toMap());
  }

  // ---------------- الملاحظات ----------------
  static List<NoteItem> allNotes() {
    final list = notes.values.map((e) => NoteItem.fromMap(e as Map)).toList();
    list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return list;
  }

  static Future<void> saveNote(NoteItem n) {
    n.updatedAt = DateTime.now();
    return notes.put(n.id, n.toMap());
  }

  // ---------------- المفضلة ----------------
  static List<BookmarkItem> allBookmarks() {
    final list =
        bookmarks.values.map((e) => BookmarkItem.fromMap(e as Map)).toList();
    list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return list;
  }

  static Future<void> saveBookmark(BookmarkItem b) {
    b.updatedAt = DateTime.now();
    return bookmarks.put(b.id, b.toMap());
  }

  // ---------------- الاشتراكات ----------------
  static List<SubscriptionItem> allSubs() {
    final list =
        subs.values.map((e) => SubscriptionItem.fromMap(e as Map)).toList();
    // الأقرب للانتهاء أولاً
    list.sort((a, b) => a.endDate.compareTo(b.endDate));
    return list;
  }

  static Future<void> saveSub(SubscriptionItem s) => subs.put(s.id, s.toMap());

  /// عدد الاشتراكات المنتهية أو القريبة من الانتهاء
  static int alertSubsCount() =>
      allSubs().where((s) => s.isExpired || s.isSoon).length;
}
