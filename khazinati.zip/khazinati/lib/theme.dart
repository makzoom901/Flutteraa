import 'package:flutter/material.dart';

/// ألوان التطبيق: أزرق + رصاصي
class AppColors {
  static const blue = Color(0xFF1E5EFF);
  static const blueDark = Color(0xFF1746C4);
  static const blueLight = Color(0xFFE6EDFF);
  static const bg = Color(0xFFF2F4F7); // رصاصي فاتح للخلفية
  static const card = Colors.white;
  static const border = Color(0xFFE3E6EB);
  static const text = Color(0xFF1F2937); // رصاصي غامق للنص
  static const textSoft = Color(0xFF6B7280); // رصاصي متوسط
  static const danger = Color(0xFFE5484D);
  static const warning = Color(0xFFF59E0B);
  static const success = Color(0xFF22A06B);

  /// ألوان جاهزة للتصنيفات
  static const palette = <Color>[
    Color(0xFF1E5EFF), // أزرق
    Color(0xFF0EA5E9), // سماوي
    Color(0xFF14B8A6), // فيروزي
    Color(0xFF22A06B), // أخضر
    Color(0xFF84CC16), // ليموني
    Color(0xFFF59E0B), // برتقالي فاتح
    Color(0xFFF97316), // برتقالي
    Color(0xFFE5484D), // أحمر
    Color(0xFFEC4899), // وردي
    Color(0xFF8B5CF6), // بنفسجي
    Color(0xFF6B7280), // رصاصي
    Color(0xFF334155), // رصاصي غامق
  ];
}

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.blue,
    brightness: Brightness.light,
  ).copyWith(
    primary: AppColors.blue,
    onPrimary: Colors.white,
    surface: AppColors.card,
    onSurface: AppColors.text,
    error: AppColors.danger,
  );

  final inputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(14),
    borderSide: const BorderSide(color: AppColors.border),
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.bg,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.bg,
      foregroundColor: AppColors.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: AppColors.text,
        fontSize: 22,
        fontWeight: FontWeight.w700,
      ),
    ),
    cardTheme: CardThemeData(
      color: AppColors.card,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: AppColors.border),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: inputBorder,
      enabledBorder: inputBorder,
      focusedBorder: inputBorder.copyWith(
        borderSide: const BorderSide(color: AppColors.blue, width: 1.6),
      ),
      labelStyle: const TextStyle(color: AppColors.textSoft),
      prefixIconColor: AppColors.textSoft,
      suffixIconColor: AppColors.textSoft,
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: AppColors.blue,
      foregroundColor: Colors.white,
      elevation: 2,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      indicatorColor: AppColors.blueLight,
      surfaceTintColor: Colors.transparent,
      height: 68,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return TextStyle(
          fontSize: 12,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          color: selected ? AppColors.blue : AppColors.textSoft,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return IconThemeData(
          color: selected ? AppColors.blue : AppColors.textSoft,
        );
      }),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.blue,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppColors.text,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    dividerColor: AppColors.border,
  );
}
