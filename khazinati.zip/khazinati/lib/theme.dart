import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// ألوان التطبيق: أزرق + رصاصي — مع وضع فاتح ووضع داكن
class AppColors {
  /// الوضع الحالي (يتغيّر من الإعدادات)
  static bool dark = false;

  // ألوان ثابتة في الوضعين
  static const blue = Color(0xFF1E5EFF);
  static const blueDark = Color(0xFF1746C4);
  static const danger = Color(0xFFE5484D);
  static const warning = Color(0xFFF59E0B);
  static const success = Color(0xFF22A06B);

  // ألوان تتغيّر حسب الوضع
  static Color get blueLight =>
      dark ? const Color(0xFF1B2A4E) : const Color(0xFFE6EDFF);
  static Color get bg => // الخلفية الرصاصية
      dark ? const Color(0xFF111418) : const Color(0xFFF2F4F7);
  static Color get card => // البطاقات والأسطح
      dark ? const Color(0xFF1B1F25) : Colors.white;
  static Color get border =>
      dark ? const Color(0xFF2C323B) : const Color(0xFFE3E6EB);
  static Color get text => // النص الأساسي
      dark ? const Color(0xFFE7E9EC) : const Color(0xFF1F2937);
  static Color get textSoft => // النص الثانوي الرصاصي
      dark ? const Color(0xFF9BA3AE) : const Color(0xFF6B7280);

  /// ألوان جاهزة للتصنيفات
  static const palette = <Color>[
    Color(0xFF1E5EFF), // أزرق
    Color(0xFF0EA5E9), // سماوي
    Color(0xFF14B8A6), // فيروزي
    Color(0xFF22A06B), // أخضر
    Color(0xFF84CC16), // ليموني
    Color(0xFFF59E0B), // برتقالي فاتح
    Color(0xFFF97316), // برتقالي
    Color(0xFFE5484D), // أحمر
    Color(0xFFEC4899), // وردي
    Color(0xFF8B5CF6), // بنفسجي
    Color(0xFF6B7280), // رصاصي
    Color(0xFF334155), // رصاصي غامق
  ];
}

SystemUiOverlayStyle systemUiStyle() {
  final dark = AppColors.dark;
  return SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
    statusBarBrightness: dark ? Brightness.dark : Brightness.light,
    systemNavigationBarColor: AppColors.card,
    systemNavigationBarIconBrightness:
        dark ? Brightness.light : Brightness.dark,
  );
}

ThemeData buildTheme() {
  final dark = AppColors.dark;
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.blue,
    brightness: dark ? Brightness.dark : Brightness.light,
  ).copyWith(
    primary: AppColors.blue,
    onPrimary: Colors.white,
    surface: AppColors.card,
    onSurface: AppColors.text,
    onSurfaceVariant: AppColors.textSoft,
    outline: AppColors.border,
    outlineVariant: AppColors.border,
    error: AppColors.danger,
  );

  final inputBorder = OutlineInputBorder(
    borderRadius: BorderRadius.circular(14),
    borderSide: BorderSide(color: AppColors.border),
  );

  return ThemeData(
    useMaterial3: true,
    fontFamily: 'Tajawal',
    brightness: dark ? Brightness.dark : Brightness.light,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.bg,
    canvasColor: AppColors.card,
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.bg,
      foregroundColor: AppColors.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      systemOverlayStyle: systemUiStyle(),
      titleTextStyle: TextStyle(
        fontFamily: 'Tajawal',
        color: AppColors.text,
        fontSize: 22,
        fontWeight: FontWeight.w700,
      ),
    ),
    cardTheme: CardThemeData(
      color: AppColors.card,
      elevation: 0,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: AppColors.border),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.card,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: inputBorder,
      enabledBorder: inputBorder,
      focusedBorder: inputBorder.copyWith(
        borderSide: const BorderSide(color: AppColors.blue, width: 1.6),
      ),
      labelStyle: TextStyle(color: AppColors.textSoft),
      hintStyle: TextStyle(color: AppColors.textSoft),
      prefixIconColor: AppColors.textSoft,
      suffixIconColor: AppColors.textSoft,
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(
      backgroundColor: AppColors.blue,
      foregroundColor: Colors.white,
      elevation: 2,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: AppColors.card,
      indicatorColor: AppColors.blueLight,
      surfaceTintColor: Colors.transparent,
      height: 68,
      labelTextStyle: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return TextStyle(
          fontFamily: 'Tajawal',
          fontSize: 12,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          color: selected ? AppColors.blue : AppColors.textSoft,
        );
      }),
      iconTheme: WidgetStateProperty.resolveWith((states) {
        final selected = states.contains(WidgetState.selected);
        return IconThemeData(
          color: selected ? AppColors.blue : AppColors.textSoft,
        );
      }),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.blue,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        textStyle: const TextStyle(
            fontFamily: 'Tajawal', fontSize: 16, fontWeight: FontWeight.w700),
      ),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: dark ? const Color(0xFF2C323B) : const Color(0xFF1F2937),
      contentTextStyle:
          const TextStyle(fontFamily: 'Tajawal', color: Colors.white),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: AppColors.card,
      surfaceTintColor: Colors.transparent,
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: AppColors.card,
      surfaceTintColor: Colors.transparent,
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: AppColors.card,
      surfaceTintColor: Colors.transparent,
    ),
    chipTheme: ChipThemeData(
      backgroundColor: AppColors.card,
      labelStyle: TextStyle(fontFamily: 'Tajawal', color: AppColors.text),
    ),
    dividerColor: AppColors.border,
  );
}
