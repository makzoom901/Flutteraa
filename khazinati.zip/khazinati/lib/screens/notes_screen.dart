import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../data/models.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';
import 'settings_screen.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  String _q = '';
  String? _cat;

  void _open([NoteItem? note]) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => NoteEditorScreen(note: note, initialCategory: _cat)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الملاحظات'),
        actions: const [SettingsButton()],
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'ملاحظة جديدة',
        onPressed: () => _open(),
        child: const Icon(Icons.add_rounded, size: 30),
      ),
      body: ListPage(
        searchHint: 'ابحث في الملاحظات',
        onSearch: (v) => setState(() => _q = v),
        category: _cat,
        onCategory: (v) => setState(() => _cat = v),
        child: ListenableBuilder(
          listenable: Listenable.merge(
              [Db.notes.listenable(), Db.categories.listenable()]),
          builder: (context, _) {
            final all = Db.allNotes();
            final items = applyFilter<NoteItem>(
                all, _q, _cat, (e, q) => e.matches(q), (e) => e.categoryId);
            if (items.isEmpty) {
              return all.isEmpty
                  ? const EmptyState(
                      icon: Icons.sticky_note_2_outlined,
                      title: 'لا توجد ملاحظات',
                      subtitle: 'ملاحظاتك تُحفظ مشفّرة وآمنة',
                    )
                  : const EmptyState(
                      icon: Icons.search_off_rounded,
                      title: 'لا توجد نتائج',
                      subtitle: 'جرّب كلمة بحث أخرى',
                    );
            }
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final n = items[i];
                return ItemCard(
                  icon: Icons.sticky_note_2_outlined,
                  title: n.title.isNotEmpty
                      ? n.title
                      : n.content.split('\n').first,
                  subtitle: n.title.isNotEmpty ? n.content : null,
                  category: Db.category(n.categoryId),
                  extra: Text(
                    formatDate(n.updatedAt),
                    style: TextStyle(
                        color: AppColors.textSoft, fontSize: 11.5),
                  ),
                  onTap: () => _open(n),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class NoteEditorScreen extends StatefulWidget {
  final NoteItem? note;
  final String? initialCategory;
  const NoteEditorScreen({super.key, this.note, this.initialCategory});

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late final TextEditingController _title, _content;
  String? _category;
  bool _deleted = false;

  @override
  void initState() {
    super.initState();
    _title = TextEditingController(text: widget.note?.title ?? '');
    _content = TextEditingController(text: widget.note?.content ?? '');
    _category = widget.note?.categoryId ?? widget.initialCategory;
  }

  @override
  void dispose() {
    _title.dispose();
    _content.dispose();
    super.dispose();
  }

  /// حفظ تلقائي عند الرجوع
  Future<void> _persist() async {
    if (_deleted) return;
    final title = _title.text.trim();
    final content = _content.text.trim();
    if (title.isEmpty && content.isEmpty) return;
    final old = widget.note;
    if (old != null &&
        old.title == title &&
        old.content == content &&
        old.categoryId == _category) {
      return; // لا تغيير
    }
    final n = old ?? NoteItem(id: newId());
    n
      ..title = title
      ..content = content
      ..categoryId = _category;
    await Db.saveNote(n);
  }

  Future<void> _delete() async {
    final n = widget.note;
    if (n == null) {
      _deleted = true;
      Navigator.pop(context);
      return;
    }
    if (await confirmDelete(context, n.title.isEmpty ? 'الملاحظة' : n.title)) {
      _deleted = true;
      await Db.notes.delete(n.id);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) _persist();
      },
      child: Scaffold(
        backgroundColor: AppColors.card,
        appBar: AppBar(
          backgroundColor: AppColors.card,
          title: Text(widget.note == null ? 'ملاحظة جديدة' : 'تعديل الملاحظة',
              style: const TextStyle(fontSize: 18)),
          actions: [
            IconButton(
              tooltip: 'نسخ النص',
              icon: const Icon(Icons.copy_rounded),
              onPressed: () => copyText(context, _content.text),
            ),
            IconButton(
              tooltip: 'حذف',
              icon: const Icon(Icons.delete_outline_rounded,
                  color: AppColors.danger),
              onPressed: _delete,
            ),
            IconButton(
              tooltip: 'حفظ',
              icon: const Icon(Icons.check_rounded, color: AppColors.blue),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                children: [
                  TextField(
                    controller: _title,
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.w800),
                    decoration: const InputDecoration(
                      hintText: 'العنوان',
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      filled: false,
                      contentPadding: EdgeInsets.symmetric(vertical: 8),
                    ),
                  ),
                  TextField(
                    controller: _content,
                    autofocus: widget.note == null,
                    maxLines: null,
                    minLines: 12,
                    keyboardType: TextInputType.multiline,
                    style: const TextStyle(fontSize: 16, height: 1.6),
                    decoration: const InputDecoration(
                      hintText: 'اكتب ملاحظتك هنا...',
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      filled: false,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
              decoration: BoxDecoration(
                color: AppColors.bg,
                border: Border(top: BorderSide(color: AppColors.border)),
              ),
              child: SafeArea(
                top: false,
                child: CategoryPicker(
                  value: _category,
                  onChanged: (v) => setState(() => _category = v),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
