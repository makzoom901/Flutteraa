import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../data/models.dart';
import '../services/app_lock.dart';
import '../services/auth_service.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/category_editor.dart';
import '../widgets/common.dart';
import '../widgets/pin_pad.dart';

/// زر الإعدادات في أعلى كل شاشة
class SettingsButton extends StatelessWidget {
  const SettingsButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: IconButton(
        tooltip: 'الإعدادات',
        icon: const Icon(Icons.settings_outlined),
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const SettingsScreen())),
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _canBio = false;
  bool _bioOn = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final can = await AuthService.canUseBiometric();
    final on = await AuthService.bioEnabled();
    if (mounted) {
      setState(() {
        _canBio = can;
        _bioOn = can && on;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _section('الأمان'),
          _group([
            SwitchListTile(
              secondary: _icon(Icons.fingerprint_rounded),
              title: const Text('الدخول بالبصمة'),
              subtitle: Text(_canBio
                  ? 'افتح التطبيق ببصمة الإصبع'
                  : 'لا توجد بصمة مسجّلة في الجهاز'),
              value: _bioOn,
              onChanged: _canBio
                  ? (v) async {
                      await AuthService.setBioEnabled(v);
                      setState(() => _bioOn = v);
                    }
                  : null,
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: _icon(Icons.password_rounded),
              title: const Text('تغيير الرمز السري'),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const ChangePinScreen())),
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: _icon(Icons.lock_outline_rounded),
              title: const Text('قفل التطبيق الآن'),
              onTap: () {
                Navigator.popUntil(context, (r) => r.isFirst);
                AppLock.lock();
              },
            ),
          ]),
          const SizedBox(height: 20),
          _section('التصنيفات'),
          _group([
            ListTile(
              leading: _icon(Icons.palette_outlined),
              title: const Text('إدارة التصنيفات والألوان'),
              subtitle: const Text('إضافة وتعديل وحذف التصنيفات'),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const CategoriesScreen())),
            ),
          ]),
          const SizedBox(height: 20),
          _section('حول التطبيق'),
          _group([
            ListTile(
              leading: _icon(Icons.verified_user_outlined),
              title: const Text('بياناتك على جهازك فقط'),
              subtitle: const Text(
                  'كل البيانات مشفّرة (AES-256) ولا تُرسل لأي خادم أو إنترنت.'),
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: _icon(Icons.info_outline_rounded),
              title: const Text('خزنتي'),
              subtitle: const Text('الإصدار 1.0.0'),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _icon(IconData i) => Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: AppColors.blueLight,
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(i, color: AppColors.blue, size: 22),
      );

  Widget _section(String t) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 6, bottom: 8),
        child: Text(t,
            style: const TextStyle(
                color: AppColors.textSoft, fontWeight: FontWeight.w700)),
      );

  Widget _group(List<Widget> children) => Card(
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );
}

// ======================= إدارة التصنيفات =======================

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التصنيفات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showCategoryEditor(context),
        icon: const Icon(Icons.add_rounded),
        label: const Text('تصنيف جديد'),
      ),
      body: ValueListenableBuilder(
        valueListenable: Db.categories.listenable(),
        builder: (context, _, __) {
          final cats = Db.allCategories();
          if (cats.isEmpty) {
            return const EmptyState(
              icon: Icons.palette_outlined,
              title: 'لا توجد تصنيفات',
              subtitle: 'أضف تصنيفاً مثل شخصي أو عمل',
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            itemCount: cats.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final c = cats[i];
              final count = Db.countInCategory(c.id);
              return Card(
                child: ListTile(
                  contentPadding:
                      const EdgeInsetsDirectional.only(start: 14, end: 4),
                  leading: CircleAvatar(
                    backgroundColor: c.colorValue,
                    child: const Icon(Icons.label_rounded,
                        color: Colors.white, size: 20),
                  ),
                  title: Text(c.name,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(count == 0 ? 'فارغ' : '$count عنصر'),
                  onTap: () => showCategoryEditor(context, existing: c),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: 'تعديل',
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () =>
                            showCategoryEditor(context, existing: c),
                      ),
                      IconButton(
                        tooltip: 'حذف',
                        icon: const Icon(Icons.delete_outline_rounded,
                            color: AppColors.danger),
                        onPressed: () => _delete(context, c, count),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _delete(BuildContext context, ItemCategory c, int count) async {
    final ok = await confirmDelete(context, c.name);
    if (!ok) return;
    await Db.deleteCategory(c.id);
    if (context.mounted && count > 0) {
      showSnack(context, 'تم الحذف، والعناصر أصبحت بدون تصنيف');
    }
  }
}

// ======================= تغيير الرمز =======================

class ChangePinScreen extends StatefulWidget {
  const ChangePinScreen({super.key});

  @override
  State<ChangePinScreen> createState() => _ChangePinScreenState();
}

class _ChangePinScreenState extends State<ChangePinScreen> {
  int _step = 0; // 0 الحالي، 1 الجديد، 2 التأكيد
  String _pin = '';
  String _new = '';
  bool _error = false;
  String _errorMsg = '';
  bool _busy = false;

  static const _titles = [
    'أدخل الرمز الحالي',
    'أدخل الرمز الجديد',
    'أكّد الرمز الجديد',
  ];

  void _onDigit(String d) {
    if (_busy || _pin.length >= AuthService.pinLength) return;
    setState(() {
      _error = false;
      _pin += d;
    });
    if (_pin.length == AuthService.pinLength) _submit();
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    if (_step == 0) {
      final ok = await AuthService.checkPin(_pin);
      setState(() {
        _error = !ok;
        _errorMsg = 'الرمز غير صحيح، حاول مرة أخرى';
        if (ok) _step = 1;
        _pin = '';
        _busy = false;
      });
    } else if (_step == 1) {
      setState(() {
        _new = _pin;
        _pin = '';
        _step = 2;
        _busy = false;
      });
    } else {
      if (_pin == _new) {
        await AuthService.setPin(_pin);
        if (mounted) {
          showSnack(context, 'تم تغيير الرمز السري');
          Navigator.pop(context);
        }
      } else {
        setState(() {
          _error = true;
          _errorMsg = 'الرمزان غير متطابقين، أدخل الرمز الجديد مرة أخرى';
          _pin = '';
          _new = '';
          _step = 1;
          _busy = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تغيير الرمز السري')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_titles[_step],
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                SizedBox(
                  height: 22,
                  child: Text(
                    _error ? _errorMsg : '',
                    style: const TextStyle(color: AppColors.danger),
                  ),
                ),
                const SizedBox(height: 20),
                PinDots(
                    length: AuthService.pinLength,
                    filled: _pin.length,
                    error: _error),
                const SizedBox(height: 32),
                PinPad(
                  enabled: !_busy,
                  onDigit: _onDigit,
                  onBackspace: () {
                    if (_pin.isNotEmpty) {
                      setState(() => _pin = _pin.substring(0, _pin.length - 1));
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
