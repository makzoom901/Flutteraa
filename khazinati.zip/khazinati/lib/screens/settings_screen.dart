import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../data/models.dart';
import '../services/app_lock.dart';
import '../services/auth_service.dart';
import '../services/backup_service.dart';
import '../services/notification_service.dart';
import '../services/theme_controller.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/category_editor.dart';
import '../widgets/common.dart';
import '../widgets/pin_pad.dart';

/// زر الإعدادات في أعلى كل شاشة
class SettingsButton extends StatelessWidget {
  const SettingsButton({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: IconButton(
        tooltip: 'الإعدادات',
        icon: const Icon(Icons.settings_outlined),
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const SettingsScreen())),
      ),
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _canBio = false;
  bool _bioOn = false;
  int _remindDays = Db.defaultRemindDays;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final can = await AuthService.canUseBiometric();
    final on = await AuthService.bioEnabled();
    if (mounted) {
      setState(() {
        _canBio = can;
        _bioOn = can && on;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _section('الأمان'),
          _group([
            SwitchListTile(
              secondary: _icon(Icons.fingerprint_rounded),
              title: const Text('الدخول بالبصمة'),
              subtitle: Text(_canBio
                  ? 'افتح التطبيق ببصمة الإصبع'
                  : 'لا توجد بصمة مسجّلة في الجهاز'),
              value: _bioOn,
              onChanged: _canBio
                  ? (v) async {
                      await AuthService.setBioEnabled(v);
                      setState(() => _bioOn = v);
                    }
                  : null,
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: _icon(Icons.password_rounded),
              title: const Text('تغيير الرمز السري'),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const ChangePinScreen())),
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: _icon(Icons.lock_outline_rounded),
              title: const Text('قفل التطبيق الآن'),
              onTap: () {
                Navigator.popUntil(context, (r) => r.isFirst);
                AppLock.lock();
              },
            ),
          ]),
          const SizedBox(height: 20),
          _section('المظهر'),
          _group([
            SwitchListTile(
              secondary: _icon(AppColors.dark
                  ? Icons.dark_mode_rounded
                  : Icons.light_mode_rounded),
              title: const Text('الوضع الداكن'),
              subtitle: Text(AppColors.dark ? 'مفعّل' : 'الوضع الفاتح مفعّل'),
              value: AppColors.dark,
              onChanged: (v) => ThemeController.setDark(v),
            ),
          ]),
          const SizedBox(height: 20),
          _section('تنبيهات الاشتراكات'),
          _group([
            ListTile(
              leading: _icon(Icons.notifications_active_outlined),
              title: const Text('التذكير قبل الانتهاء'),
              subtitle: Text(_remindDays == 0
                  ? 'بدون تذكير مسبق (فقط يوم الانتهاء)'
                  : 'قبل ${daysText(_remindDays)} من الانتهاء'),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              child: Row(
                children: [
                  _stepButton(Icons.remove_rounded,
                      _remindDays > 0 ? () => _setRemind(_remindDays - 1) : null),
                  Expanded(
                    child: Text(
                      _remindDays == 0 ? 'بدون' : daysText(_remindDays),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w800),
                    ),
                  ),
                  _stepButton(Icons.add_rounded,
                      _remindDays < 60 ? () => _setRemind(_remindDays + 1) : null),
                ],
              ),
            ),
            Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: _icon(Icons.done_all_rounded),
              title: const Text('تطبيق على كل الاشتراكات الحالية'),
              subtitle: const Text('الاشتراكات الجديدة تأخذ هذا العدد تلقائياً'),
              onTap: _applyRemindToAll,
            ),
          ]),
          const SizedBox(height: 20),
          _section('النسخ الاحتياطي'),
          _group([
            ListTile(
              leading: _icon(Icons.download_rounded),
              title: const Text('تنزيل نسخة احتياطية'),
              subtitle: const Text('حفظ كل البيانات في ملف مشفّر بكلمة مرور'),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _exportBackup,
            ),
            Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: _icon(Icons.restore_rounded),
              title: const Text('استعادة نسخة احتياطية'),
              subtitle: const Text('استبدال البيانات الحالية بملف نسخة سابقة'),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: _importBackup,
            ),
          ]),
          const SizedBox(height: 20),
          _section('التصنيفات'),
          _group([
            ListTile(
              leading: _icon(Icons.palette_outlined),
              title: const Text('إدارة التصنيفات والألوان'),
              subtitle: const Text('إضافة وتعديل وحذف التصنيفات'),
              trailing: const Icon(Icons.chevron_left_rounded),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const CategoriesScreen())),
            ),
          ]),
          const SizedBox(height: 20),
          _section('حول التطبيق'),
          _group([
            ListTile(
              leading: _icon(Icons.verified_user_outlined),
              title: const Text('بياناتك على جهازك فقط'),
              subtitle: const Text(
                  'كل البيانات مشفّرة (AES-256) ولا تُرسل لأي خادم. يُستخدم الإنترنت فقط لجلب شعارات المواقع.'),
            ),
            const Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(
              leading: _icon(Icons.info_outline_rounded),
              title: const Text('خزنتي'),
              subtitle: const Text('الإصدار 1.1.0'),
            ),
          ]),
        ],
      ),
    );
  }

  // ---------------- التذكير ----------------
  Future<void> _setRemind(int v) async {
    setState(() => _remindDays = v);
    await Db.setDefaultRemindDays(v);
  }

  Widget _stepButton(IconData icon, VoidCallback? onTap) {
    return Material(
      color: onTap == null ? AppColors.bg : AppColors.blueLight,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: SizedBox(
          width: 52,
          height: 44,
          child: Icon(icon,
              color: onTap == null ? AppColors.textSoft : AppColors.blue),
        ),
      ),
    );
  }

  Future<void> _applyRemindToAll() async {
    final subs = Db.allSubs();
    if (subs.isEmpty) {
      showSnack(context, 'لا توجد اشتراكات بعد');
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تطبيق على الكل'),
        content: Text(
            'سيتم ضبط التذكير لـ ${subs.length} اشتراك على: ${_remindDays == 0 ? 'بدون تذكير مسبق' : 'قبل ${daysText(_remindDays)}'}'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('تطبيق')),
        ],
      ),
    );
    if (ok != true) return;
    for (final s in subs) {
      s.remindDays = _remindDays;
      await Db.saveSub(s);
      await NotificationService.scheduleFor(s);
    }
    if (mounted) showSnack(context, 'تم تحديث ${subs.length} اشتراك');
  }

  // ---------------- النسخ الاحتياطي ----------------
  Future<T?> _withProgress<T>(String text, Future<T> Function() job) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => PopScope(
        canPop: false,
        child: AlertDialog(
          content: Row(
            children: [
              const SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(strokeWidth: 3)),
              const SizedBox(width: 18),
              Expanded(child: Text(text)),
            ],
          ),
        ),
      ),
    );
    try {
      return await job();
    } finally {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
    }
  }

  Future<void> _exportBackup() async {
    final password = await _askBackupPassword(confirm: true);
    if (password == null || !mounted) return;
    try {
      final bytes = await _withProgress(
          'جارٍ تجهيز النسخة الاحتياطية...', () => BackupService.create(password));
      if (bytes == null || !mounted) return;
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'حفظ النسخة الاحتياطية',
        fileName: BackupService.fileName(),
        bytes: bytes,
      );
      if (!mounted) return;
      if (path == null) {
        showSnack(context, 'تم الإلغاء');
      } else {
        showSnack(context, 'تم حفظ النسخة الاحتياطية ✅');
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر حفظ النسخة: $e');
    }
  }

  Future<void> _importBackup() async {
    FilePickerResult? picked;
    try {
      picked = await FilePicker.platform.pickFiles(
        dialogTitle: 'اختر ملف النسخة الاحتياطية',
        type: FileType.any,
        withData: true,
      );
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر فتح الملف');
      return;
    }
    final bytes = picked?.files.single.bytes;
    if (bytes == null || !mounted) return;

    final password = await _askBackupPassword(confirm: false);
    if (password == null || !mounted) return;

    Map<String, dynamic>? data;
    try {
      data = await _withProgress(
          'جارٍ فك التشفير...', () => BackupService.read(bytes, password));
    } on BackupException catch (e) {
      if (mounted) showSnack(context, e.message);
      return;
    }
    if (data == null || !mounted) return;

    final count = Db.countItems(data);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('استعادة النسخة'),
        content: Text(
            'تحتوي النسخة على $count عنصر.\nسيتم حذف كل البيانات الحالية واستبدالها بها. هل تريد المتابعة؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.danger),
            child: const Text('استعادة'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    await Db.importAll(data);
    await NotificationService.cancelAll();
    await NotificationService.rescheduleAll();
    ThemeController.apply(Db.darkMode);
    if (mounted) {
      setState(() => _remindDays = Db.defaultRemindDays);
      showSnack(context, 'تمت استعادة البيانات ✅');
    }
  }

  /// نافذة إدخال كلمة مرور النسخة الاحتياطية
  Future<String?> _askBackupPassword({required bool confirm}) {
    return showDialog<String>(
      context: context,
      builder: (_) => _BackupPasswordDialog(confirm: confirm),
    );
  }

  Widget _icon(IconData i) => Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: AppColors.blueLight,
          borderRadius: BorderRadius.circular(11),
        ),
        child: Icon(i, color: AppColors.blue, size: 22),
      );

  Widget _section(String t) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 6, bottom: 8),
        child: Text(t,
            style: TextStyle(
                color: AppColors.textSoft, fontWeight: FontWeight.w700)),
      );

  Widget _group(List<Widget> children) => Card(
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );
}

// ======================= إدارة التصنيفات =======================

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التصنيفات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showCategoryEditor(context),
        icon: const Icon(Icons.add_rounded),
        label: const Text('تصنيف جديد'),
      ),
      body: ValueListenableBuilder(
        valueListenable: Db.categories.listenable(),
        builder: (context, _, __) {
          final cats = Db.allCategories();
          if (cats.isEmpty) {
            return const EmptyState(
              icon: Icons.palette_outlined,
              title: 'لا توجد تصنيفات',
              subtitle: 'أضف تصنيفاً مثل شخصي أو عمل',
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            itemCount: cats.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final c = cats[i];
              final count = Db.countInCategory(c.id);
              return Card(
                child: ListTile(
                  contentPadding:
                      const EdgeInsetsDirectional.only(start: 14, end: 4),
                  leading: CircleAvatar(
                    backgroundColor: c.colorValue,
                    child: const Icon(Icons.label_rounded,
                        color: Colors.white, size: 20),
                  ),
                  title: Text(c.name,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(count == 0 ? 'فارغ' : '$count عنصر'),
                  onTap: () => showCategoryEditor(context, existing: c),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        tooltip: 'تعديل',
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () =>
                            showCategoryEditor(context, existing: c),
                      ),
                      IconButton(
                        tooltip: 'حذف',
                        icon: const Icon(Icons.delete_outline_rounded,
                            color: AppColors.danger),
                        onPressed: () => _delete(context, c, count),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _delete(BuildContext context, ItemCategory c, int count) async {
    final ok = await confirmDelete(context, c.name);
    if (!ok) return;
    await Db.deleteCategory(c.id);
    if (context.mounted && count > 0) {
      showSnack(context, 'تم الحذف، والعناصر أصبحت بدون تصنيف');
    }
  }
}

// ======================= تغيير الرمز =======================

class ChangePinScreen extends StatefulWidget {
  const ChangePinScreen({super.key});

  @override
  State<ChangePinScreen> createState() => _ChangePinScreenState();
}

class _ChangePinScreenState extends State<ChangePinScreen> {
  int _step = 0; // 0 الحالي، 1 الجديد، 2 التأكيد
  String _pin = '';
  String _new = '';
  bool _error = false;
  String _errorMsg = '';
  bool _busy = false;

  static const _titles = [
    'أدخل الرمز الحالي',
    'أدخل الرمز الجديد',
    'أكّد الرمز الجديد',
  ];

  void _onDigit(String d) {
    if (_busy || _pin.length >= AuthService.pinLength) return;
    setState(() {
      _error = false;
      _pin += d;
    });
    if (_pin.length == AuthService.pinLength) _submit();
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    if (_step == 0) {
      final ok = await AuthService.checkPin(_pin);
      setState(() {
        _error = !ok;
        _errorMsg = 'الرمز غير صحيح، حاول مرة أخرى';
        if (ok) _step = 1;
        _pin = '';
        _busy = false;
      });
    } else if (_step == 1) {
      setState(() {
        _new = _pin;
        _pin = '';
        _step = 2;
        _busy = false;
      });
    } else {
      if (_pin == _new) {
        await AuthService.setPin(_pin);
        if (mounted) {
          showSnack(context, 'تم تغيير الرمز السري');
          Navigator.pop(context);
        }
      } else {
        setState(() {
          _error = true;
          _errorMsg = 'الرمزان غير متطابقين، أدخل الرمز الجديد مرة أخرى';
          _pin = '';
          _new = '';
          _step = 1;
          _busy = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تغيير الرمز السري')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_titles[_step],
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                SizedBox(
                  height: 22,
                  child: Text(
                    _error ? _errorMsg : '',
                    style: const TextStyle(color: AppColors.danger),
                  ),
                ),
                const SizedBox(height: 20),
                PinDots(
                    length: AuthService.pinLength,
                    filled: _pin.length,
                    error: _error),
                const SizedBox(height: 32),
                PinPad(
                  enabled: !_busy,
                  onDigit: _onDigit,
                  onBackspace: () {
                    if (_pin.isNotEmpty) {
                      setState(() => _pin = _pin.substring(0, _pin.length - 1));
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ======================= كلمة مرور النسخة الاحتياطية =======================

class _BackupPasswordDialog extends StatefulWidget {
  final bool confirm;
  const _BackupPasswordDialog({required this.confirm});

  @override
  State<_BackupPasswordDialog> createState() => _BackupPasswordDialogState();
}

class _BackupPasswordDialogState extends State<_BackupPasswordDialog> {
  final _p1 = TextEditingController();
  final _p2 = TextEditingController();
  bool _obscure = true;
  String? _error;

  @override
  void dispose() {
    _p1.dispose();
    _p2.dispose();
    super.dispose();
  }

  void _submit() {
    final p = _p1.text;
    if (widget.confirm) {
      if (p.length < 6) {
        setState(() => _error = 'كلمة المرور 6 أحرف على الأقل');
        return;
      }
      if (p != _p2.text) {
        setState(() => _error = 'كلمتا المرور غير متطابقتين');
        return;
      }
    } else if (p.isEmpty) {
      setState(() => _error = 'اكتب كلمة المرور');
      return;
    }
    Navigator.pop(context, p);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.confirm
          ? 'كلمة مرور النسخة الاحتياطية'
          : 'كلمة مرور النسخة'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (widget.confirm)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(
                  'احفظ هذه الكلمة جيداً، بدونها لا يمكن استعادة النسخة.',
                  style: TextStyle(color: AppColors.textSoft, fontSize: 13),
                ),
              ),
            TextField(
              controller: _p1,
              autofocus: true,
              obscureText: _obscure,
              textDirection: TextDirection.ltr,
              onSubmitted: (_) {
                if (!widget.confirm) _submit();
              },
              decoration: InputDecoration(
                labelText: 'كلمة المرور',
                prefixIcon: const Icon(Icons.lock_outline_rounded),
                suffixIcon: IconButton(
                  icon: Icon(_obscure
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
              ),
            ),
            if (widget.confirm) ...[
              const SizedBox(height: 10),
              TextField(
                controller: _p2,
                obscureText: _obscure,
                textDirection: TextDirection.ltr,
                onSubmitted: (_) => _submit(),
                decoration: const InputDecoration(
                  labelText: 'تأكيد كلمة المرور',
                  prefixIcon: Icon(Icons.lock_outline_rounded),
                ),
              ),
            ],
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(_error!, style: const TextStyle(color: AppColors.danger)),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء')),
        FilledButton(
          onPressed: _submit,
          style: FilledButton.styleFrom(minimumSize: const Size(88, 44)),
          child: const Text('متابعة'),
        ),
      ],
    );
  }
}
