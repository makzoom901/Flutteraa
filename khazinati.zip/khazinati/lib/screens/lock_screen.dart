import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/app_lock.dart';
import '../services/auth_service.dart';
import '../theme.dart';
import '../widgets/pin_pad.dart';

enum _Mode { loading, unlock, setup, confirm }

/// شاشة القفل: إنشاء الرمز أول مرة، ثم الدخول بالبصمة أو الرمز
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  _Mode _mode = _Mode.loading;
  String _pin = '';
  String _first = '';
  bool _error = false;
  bool _busy = false;
  bool _bio = false;
  int _fails = 0;
  DateTime? _blockedUntil;
  Timer? _ticker;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  Future<void> _init() async {
    final hasPin = await AuthService.hasPin();
    final canBio = await AuthService.canUseBiometric();
    final bioOn = await AuthService.bioEnabled();
    if (!mounted) return;
    setState(() {
      _mode = hasPin ? _Mode.unlock : _Mode.setup;
      _bio = hasPin && canBio && bioOn;
    });
    if (_bio) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _tryBio());
    }
  }

  Future<void> _tryBio() async {
    if (_busy) return;
    final ok = await AuthService.authenticateBiometric();
    if (ok) AppLock.unlock();
  }

  bool get _blocked =>
      _blockedUntil != null && DateTime.now().isBefore(_blockedUntil!);

  String get _title {
    switch (_mode) {
      case _Mode.loading:
        return '';
      case _Mode.unlock:
        return 'أدخل الرمز السري';
      case _Mode.setup:
        return 'أنشئ رمزاً سرياً';
      case _Mode.confirm:
        return 'أعد إدخال الرمز للتأكيد';
    }
  }

  String get _subtitle {
    if (_blocked) {
      final s = _blockedUntil!.difference(DateTime.now()).inSeconds + 1;
      return 'محاولات كثيرة، انتظر $s ثانية';
    }
    if (_error) {
      return _mode == _Mode.unlock
          ? 'الرمز غير صحيح، حاول مرة أخرى'
          : 'الرمزان غير متطابقين، ابدأ من جديد';
    }
    switch (_mode) {
      case _Mode.setup:
        return 'رمز من ${AuthService.pinLength} أرقام لحماية بياناتك';
      case _Mode.unlock:
        return _bio ? 'أو استخدم البصمة' : '';
      default:
        return '';
    }
  }

  void _onDigit(String d) {
    if (_busy || _blocked || _pin.length >= AuthService.pinLength) return;
    HapticFeedback.selectionClick();
    setState(() {
      _error = false;
      _pin += d;
    });
    if (_pin.length == AuthService.pinLength) _submit();
  }

  void _onBack() {
    if (_pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  Future<void> _submit() async {
    setState(() => _busy = true);
    await Future<void>.delayed(const Duration(milliseconds: 120));

    switch (_mode) {
      case _Mode.setup:
        setState(() {
          _first = _pin;
          _pin = '';
          _mode = _Mode.confirm;
          _busy = false;
        });
        return;

      case _Mode.confirm:
        if (_pin == _first) {
          await AuthService.setPin(_pin);
          final canBio = await AuthService.canUseBiometric();
          await AuthService.setBioEnabled(canBio);
          AppLock.unlock();
        } else {
          HapticFeedback.heavyImpact();
          setState(() {
            _error = true;
            _pin = '';
            _first = '';
            _mode = _Mode.setup;
            _busy = false;
          });
        }
        return;

      case _Mode.unlock:
        final ok = await AuthService.checkPin(_pin);
        if (ok) {
          AppLock.unlock();
          return;
        }
        HapticFeedback.heavyImpact();
        _fails++;
        setState(() {
          _error = true;
          _pin = '';
          _busy = false;
          if (_fails >= 5) {
            _fails = 0;
            _blockedUntil = DateTime.now().add(const Duration(seconds: 30));
            _ticker?.cancel();
            _ticker = Timer.periodic(const Duration(seconds: 1), (t) {
              if (!mounted) return;
              if (!_blocked) {
                t.cancel();
                _blockedUntil = null;
                _error = false;
              }
              setState(() {});
            });
          }
        });
        return;

      case _Mode.loading:
        return;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: _mode == _Mode.loading
            ? const Center(child: CircularProgressIndicator())
            : LayoutBuilder(
                builder: (context, c) => SingleChildScrollView(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(minHeight: c.maxHeight),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        const SizedBox(height: 24),
                        Container(
                          width: 84,
                          height: 84,
                          decoration: BoxDecoration(
                            color: AppColors.blue,
                            borderRadius: BorderRadius.circular(26),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.blue.withValues(alpha: 0.3),
                                blurRadius: 24,
                                offset: const Offset(0, 10),
                              ),
                            ],
                          ),
                          child: const Icon(Icons.shield_rounded,
                              color: Colors.white, size: 46),
                        ),
                        const SizedBox(height: 14),
                        const Text('خزنتي',
                            style: TextStyle(
                                fontSize: 26, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 28),
                        Text(_title,
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        SizedBox(
                          height: 22,
                          child: Text(
                            _subtitle,
                            style: TextStyle(
                              color: (_error || _blocked)
                                  ? AppColors.danger
                                  : AppColors.textSoft,
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        PinDots(
                          length: AuthService.pinLength,
                          filled: _pin.length,
                          error: _error,
                        ),
                        const SizedBox(height: 28),
                        PinPad(
                          enabled: !_busy && !_blocked,
                          onDigit: _onDigit,
                          onBackspace: _onBack,
                          onBiometric:
                              (_mode == _Mode.unlock && _bio) ? _tryBio : null,
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                ),
              ),
      ),
    );
  }
}
