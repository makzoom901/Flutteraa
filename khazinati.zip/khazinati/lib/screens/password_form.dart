import 'package:flutter/material.dart';

import '../data/db.dart';
import '../data/models.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';

class PasswordFormScreen extends StatefulWidget {
  final PasswordItem? item;
  final String? initialCategory;
  const PasswordFormScreen({super.key, this.item, this.initialCategory});

  @override
  State<PasswordFormScreen> createState() => _PasswordFormScreenState();
}

class _PasswordFormScreenState extends State<PasswordFormScreen> {
  late final TextEditingController _title, _user, _pass, _url, _note;
  String? _category;
  bool _obscure = true;

  bool get _isEdit => widget.item != null;

  @override
  void initState() {
    super.initState();
    final p = widget.item;
    _title = TextEditingController(text: p?.title ?? '');
    _user = TextEditingController(text: p?.username ?? '');
    _pass = TextEditingController(text: p?.password ?? '');
    _url = TextEditingController(text: p?.url ?? '');
    _note = TextEditingController(text: p?.note ?? '');
    _category = p?.categoryId ?? widget.initialCategory;
    _pass.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    for (final c in [_title, _user, _pass, _url, _note]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    var title = _title.text.trim();
    final url = _url.text.trim();
    if (title.isEmpty && url.isNotEmpty) title = domainOf(url);
    if (title.isEmpty) {
      showSnack(context, 'اكتب اسم الموقع أو الخدمة');
      return;
    }
    final p = widget.item ?? PasswordItem(id: newId());
    p
      ..title = title
      ..username = _user.text.trim()
      ..password = _pass.text
      ..url = url
      ..note = _note.text.trim()
      ..categoryId = _category;
    await Db.savePassword(p);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final p = widget.item!;
    if (await confirmDelete(context, p.title)) {
      await Db.passwords.delete(p.id);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final strength = passwordStrength(_pass.text);
    const strengthLabels = ['', 'ضعيفة', 'مقبولة', 'جيدة', 'قوية'];
    const strengthColors = [
      AppColors.border,
      AppColors.danger,
      AppColors.warning,
      AppColors.blue,
      AppColors.success,
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(_isEdit ? 'تعديل كلمة المرور' : 'كلمة مرور جديدة'),
        actions: [
          if (_isEdit)
            IconButton(
              tooltip: 'حذف',
              icon: const Icon(Icons.delete_outline_rounded,
                  color: AppColors.danger),
              onPressed: _delete,
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _title,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'اسم الموقع / الخدمة',
              prefixIcon: Icon(Icons.public_rounded),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _user,
            textInputAction: TextInputAction.next,
            keyboardType: TextInputType.emailAddress,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
              labelText: 'اسم المستخدم / البريد',
              prefixIcon: Icon(Icons.person_outline_rounded),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _pass,
            obscureText: _obscure,
            enableSuggestions: false,
            autocorrect: false,
            textDirection: TextDirection.ltr,
            decoration: InputDecoration(
              labelText: 'كلمة المرور',
              prefixIcon: const Icon(Icons.lock_outline_rounded),
              suffixIcon: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    tooltip: _obscure ? 'إظهار' : 'إخفاء',
                    icon: Icon(_obscure
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  ),
                  IconButton(
                    tooltip: 'توليد كلمة مرور قوية',
                    icon: const Icon(Icons.auto_awesome_rounded,
                        color: AppColors.blue),
                    onPressed: () {
                      _pass.text = generatePassword();
                      setState(() => _obscure = false);
                    },
                  ),
                ],
              ),
            ),
          ),
          if (_pass.text.isNotEmpty) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                for (var i = 1; i <= 4; i++)
                  Expanded(
                    child: Container(
                      height: 5,
                      margin: const EdgeInsetsDirectional.only(end: 4),
                      decoration: BoxDecoration(
                        color: i <= strength
                            ? strengthColors[strength]
                            : AppColors.border,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                const SizedBox(width: 8),
                Text(
                  strengthLabels[strength],
                  style: TextStyle(
                      color: strengthColors[strength],
                      fontSize: 12,
                      fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ],
          const SizedBox(height: 12),
          TextField(
            controller: _url,
            keyboardType: TextInputType.url,
            textDirection: TextDirection.ltr,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'رابط الموقع (اختياري)',
              prefixIcon: Icon(Icons.link_rounded),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _note,
            minLines: 2,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: 'ملاحظات (اختياري)',
              prefixIcon: Icon(Icons.notes_rounded),
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 16),
          CategoryPicker(
            value: _category,
            onChanged: (v) => setState(() => _category = v),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check_rounded),
            label: const Text('حفظ'),
          ),
        ],
      ),
    );
  }
}
