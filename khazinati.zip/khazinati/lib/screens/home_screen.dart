import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../theme.dart';
import 'bookmarks_screen.dart';
import 'notes_screen.dart';
import 'passwords_screen.dart';
import 'subscriptions_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  static const _pages = [
    PasswordsScreen(),
    NotesScreen(),
    BookmarksScreen(),
    SubscriptionsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppColors.border)),
        ),
        child: ValueListenableBuilder(
          valueListenable: Db.subs.listenable(),
          builder: (context, _, __) {
            final alerts = Db.alertSubsCount();
            return NavigationBar(
              selectedIndex: _index,
              onDestinationSelected: (i) {
                FocusScope.of(context).unfocus();
                setState(() => _index = i);
              },
              destinations: [
                const NavigationDestination(
                  icon: Icon(Icons.key_outlined),
                  selectedIcon: Icon(Icons.key_rounded),
                  label: 'كلمات المرور',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.sticky_note_2_outlined),
                  selectedIcon: Icon(Icons.sticky_note_2_rounded),
                  label: 'الملاحظات',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.star_outline_rounded),
                  selectedIcon: Icon(Icons.star_rounded),
                  label: 'المفضلة',
                ),
                NavigationDestination(
                  icon: Badge(
                    isLabelVisible: alerts > 0,
                    label: Text('$alerts'),
                    child: const Icon(Icons.event_repeat_outlined),
                  ),
                  selectedIcon: Badge(
                    isLabelVisible: alerts > 0,
                    label: Text('$alerts'),
                    child: const Icon(Icons.event_repeat_rounded),
                  ),
                  label: 'الاشتراكات',
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
