import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../data/models.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';
import 'password_form.dart';
import 'settings_screen.dart';

class PasswordsScreen extends StatefulWidget {
  const PasswordsScreen({super.key});

  @override
  State<PasswordsScreen> createState() => _PasswordsScreenState();
}

class _PasswordsScreenState extends State<PasswordsScreen> {
  String _q = '';
  String? _cat;

  void _openForm([PasswordItem? item]) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PasswordFormScreen(item: item, initialCategory: _cat),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('كلمات المرور'),
        actions: const [SettingsButton()],
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'إضافة',
        onPressed: () => _openForm(),
        child: const Icon(Icons.add_rounded, size: 30),
      ),
      body: ListPage(
        searchHint: 'ابحث بالاسم أو المستخدم أو الرابط',
        onSearch: (v) => setState(() => _q = v),
        category: _cat,
        onCategory: (v) => setState(() => _cat = v),
        child: ListenableBuilder(
          listenable: Listenable.merge(
              [Db.passwords.listenable(), Db.categories.listenable()]),
          builder: (context, _) {
            final all = Db.allPasswords();
            final items = applyFilter<PasswordItem>(all, _q, _cat,
                (e, q) => e.matches(q), (e) => e.categoryId);
            if (items.isEmpty) {
              return all.isEmpty
                  ? const EmptyState(
                      icon: Icons.key_rounded,
                      title: 'لا توجد كلمات مرور',
                      subtitle: 'اضغط زر + لإضافة أول حساب',
                    )
                  : const EmptyState(
                      icon: Icons.search_off_rounded,
                      title: 'لا توجد نتائج',
                      subtitle: 'جرّب كلمة بحث أخرى',
                    );
            }
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final p = items[i];
                return ItemCard(
                  icon: Icons.key_rounded,
                  siteIcon: p.icon,
                  title: p.title,
                  subtitle: p.username.isNotEmpty ? p.username : domainOf(p.url),
                  category: Db.category(p.categoryId),
                  onTap: () => _showDetails(p),
                  onLongPress: () => _openForm(p),
                  trailing: IconButton(
                    tooltip: 'نسخ كلمة المرور',
                    icon: const Icon(Icons.copy_rounded, color: AppColors.blue),
                    onPressed: () => copyText(context, p.password,
                        label: 'تم نسخ كلمة المرور', sensitive: true),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  void _showDetails(PasswordItem p) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.card,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => _PasswordDetails(
        item: p,
        onEdit: () {
          Navigator.pop(ctx);
          _openForm(p);
        },
      ),
    );
  }
}

class _PasswordDetails extends StatefulWidget {
  final PasswordItem item;
  final VoidCallback onEdit;
  const _PasswordDetails({required this.item, required this.onEdit});

  @override
  State<_PasswordDetails> createState() => _PasswordDetailsState();
}

class _PasswordDetailsState extends State<_PasswordDetails> {
  bool _show = false;

  @override
  Widget build(BuildContext context) {
    final p = widget.item;
    final cat = Db.category(p.categoryId);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: AppColors.border,
                    borderRadius: BorderRadius.circular(4)),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                SiteAvatar(
                  icon: Icons.key_rounded,
                  siteIcon: p.icon,
                  color: cat?.colorValue ?? AppColors.textSoft,
                  size: 44,
                ),
                const SizedBox(width: 12),
                Flexible(
                  child: Text(p.title,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.w800)),
                ),
                const SizedBox(width: 8),
                CategoryTag(category: cat),
              ],
            ),
            const SizedBox(height: 16),
            if (p.username.isNotEmpty)
              _row(Icons.person_outline_rounded, 'اسم المستخدم', p.username,
                  onCopy: () => copyText(context, p.username,
                      label: 'تم نسخ اسم المستخدم')),
            _row(
              Icons.lock_outline_rounded,
              'كلمة المرور',
              p.password.isEmpty
                  ? '—'
                  : (_show ? p.password : '•' * 10),
              extra: IconButton(
                icon: Icon(_show
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined),
                onPressed: () => setState(() => _show = !_show),
              ),
              onCopy: () => copyText(context, p.password,
                  label: 'تم نسخ كلمة المرور', sensitive: true),
            ),
            if (p.url.isNotEmpty)
              _row(Icons.link_rounded, 'الموقع', p.url,
                  extra: IconButton(
                    icon: const Icon(Icons.open_in_new_rounded),
                    onPressed: () => openUrl(context, p.url),
                  ),
                  onCopy: () =>
                      copyText(context, p.url, label: 'تم نسخ الرابط')),
            if (p.note.isNotEmpty)
              _row(Icons.notes_rounded, 'ملاحظات', p.note, ltr: false),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: widget.onEdit,
              icon: const Icon(Icons.edit_rounded),
              label: const Text('تعديل'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(IconData icon, String label, String value,
      {VoidCallback? onCopy, Widget? extra, bool ltr = true}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
      decoration: BoxDecoration(
        color: AppColors.bg,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.textSoft),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        color: AppColors.textSoft, fontSize: 12)),
                const SizedBox(height: 2),
                Text(
                  value,
                  textDirection: ltr ? TextDirection.ltr : null,
                  style: const TextStyle(
                      fontSize: 15.5, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          if (extra != null) extra,
          if (onCopy != null)
            IconButton(
              icon: const Icon(Icons.copy_rounded, color: AppColors.blue),
              onPressed: onCopy,
            ),
        ],
      ),
    );
  }
}
