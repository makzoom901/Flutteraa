import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../data/models.dart';
import '../services/notification_service.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';
import 'settings_screen.dart';

class SubscriptionsScreen extends StatefulWidget {
  const SubscriptionsScreen({super.key});

  @override
  State<SubscriptionsScreen> createState() => _SubscriptionsScreenState();
}

class _SubscriptionsScreenState extends State<SubscriptionsScreen> {
  String _q = '';
  String? _cat;

  void _openForm([SubscriptionItem? item]) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) =>
              SubscriptionFormScreen(item: item, initialCategory: _cat)),
    );
  }

  Future<void> _renew(SubscriptionItem s) async {
    s.renew();
    await Db.saveSub(s);
    await NotificationService.scheduleFor(s);
    if (mounted) showSnack(context, 'تم التجديد حتى ${formatDate(s.endDate)}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الاشتراكات'),
        actions: const [SettingsButton()],
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'إضافة اشتراك',
        onPressed: () => _openForm(),
        child: const Icon(Icons.add_rounded, size: 30),
      ),
      body: ListenableBuilder(
        listenable:
            Listenable.merge([Db.subs.listenable(), Db.categories.listenable()]),
        builder: (context, _) {
          final all = Db.allSubs();
          final items = applyFilter<SubscriptionItem>(
              all, _q, _cat, (e, q) => e.matches(q), (e) => e.categoryId);
          final alerts = all.where((s) => s.isExpired || s.isSoon).length;

          return ListPage(
            searchHint: 'ابحث في الاشتراكات',
            onSearch: (v) => setState(() => _q = v),
            category: _cat,
            onCategory: (v) => setState(() => _cat = v),
            header: alerts > 0 ? _AlertBanner(count: alerts) : null,
            child: items.isEmpty
                ? (all.isEmpty
                    ? const EmptyState(
                        icon: Icons.event_repeat_rounded,
                        title: 'لا توجد اشتراكات',
                        subtitle:
                            'أضف اشتراكاتك وسننبّهك قبل انتهائها',
                      )
                    : const EmptyState(
                        icon: Icons.search_off_rounded,
                        title: 'لا توجد نتائج',
                        subtitle: 'جرّب كلمة بحث أخرى',
                      ))
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (context, i) {
                      final s = items[i];
                      final parts = <String>[
                        'ينتهي ${formatDate(s.endDate)}',
                        s.period.label,
                        if (s.price.isNotEmpty) s.price,
                      ];
                      return ItemCard(
                        icon: Icons.event_repeat_rounded,
                        title: s.name,
                        subtitle: parts.join(' • '),
                        category: Db.category(s.categoryId),
                        extra: _StatusLine(sub: s),
                        onTap: () => _openForm(s),
                        trailing: (s.isExpired || s.isSoon)
                            ? IconButton(
                                tooltip: 'تجديد',
                                icon: const Icon(Icons.autorenew_rounded,
                                    color: AppColors.blue),
                                onPressed: () => _renew(s),
                              )
                            : null,
                      );
                    },
                  ),
          );
        },
      ),
    );
  }
}

class _AlertBanner extends StatelessWidget {
  final int count;
  const _AlertBanner({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.warning.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.warning.withValues(alpha: 0.4)),
      ),
      child: Row(
        children: [
          const Icon(Icons.notifications_active_outlined,
              color: AppColors.warning),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              count == 1
                  ? 'لديك اشتراك واحد منتهٍ أو ينتهي قريباً'
                  : 'لديك $count اشتراكات منتهية أو تنتهي قريباً',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}

/// حالة الاشتراك + شريط التقدم
class _StatusLine extends StatelessWidget {
  final SubscriptionItem sub;
  const _StatusLine({required this.sub});

  @override
  Widget build(BuildContext context) {
    final d = sub.daysLeft;
    final Color color;
    final String text;
    if (d < 0) {
      color = AppColors.danger;
      text = 'منتهي منذ ${daysText(d)}';
    } else if (d == 0) {
      color = AppColors.danger;
      text = 'ينتهي اليوم';
    } else if (sub.isSoon) {
      color = AppColors.warning;
      text = 'متبقي ${daysText(d)}';
    } else {
      color = AppColors.success;
      text = 'متبقي ${daysText(d)}';
    }

    final total = sub.endDate.difference(sub.startDate).inDays;
    final used = DateTime.now().difference(sub.startDate).inDays;
    final progress =
        total <= 0 ? 1.0 : (used / total).clamp(0.0, 1.0).toDouble();

    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(text,
              style: TextStyle(
                  color: color, fontSize: 12, fontWeight: FontWeight.w700)),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 5,
              backgroundColor: AppColors.border,
              color: color,
            ),
          ),
        ),
        const SizedBox(width: 8),
      ],
    );
  }
}

// ======================= نموذج الاشتراك =======================

class SubscriptionFormScreen extends StatefulWidget {
  final SubscriptionItem? item;
  final String? initialCategory;
  const SubscriptionFormScreen({super.key, this.item, this.initialCategory});

  @override
  State<SubscriptionFormScreen> createState() => _SubscriptionFormScreenState();
}

class _SubscriptionFormScreenState extends State<SubscriptionFormScreen> {
  late final TextEditingController _name, _url, _price, _note;
  late DateTime _start;
  late DateTime _end;
  late SubPeriod _period;
  late int _remind;
  String? _category;

  static const _remindOptions = [0, 1, 3, 7, 14];

  @override
  void initState() {
    super.initState();
    final s = widget.item;
    _name = TextEditingController(text: s?.name ?? '');
    _url = TextEditingController(text: s?.url ?? '');
    _price = TextEditingController(text: s?.price ?? '');
    _note = TextEditingController(text: s?.note ?? '');
    final now = DateTime.now();
    _start = s?.startDate ?? DateTime(now.year, now.month, now.day);
    _period = s?.period ?? SubPeriod.monthly;
    _end = s?.endDate ?? addMonths(_start, _period.months);
    _remind = s?.remindDays ?? 3;
    _category = s?.categoryId ?? widget.initialCategory;
  }

  @override
  void dispose() {
    for (final c in [_name, _url, _price, _note]) {
      c.dispose();
    }
    super.dispose();
  }

  void _recalcEnd() {
    if (_period != SubPeriod.custom) {
      _end = addMonths(_start, _period.months);
    }
  }

  Future<DateTime?> _pick(DateTime initial) => showDatePicker(
        context: context,
        initialDate: initial,
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
      );

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      showSnack(context, 'اكتب اسم الخدمة أو الموقع');
      return;
    }
    if (!_end.isAfter(_start)) {
      showSnack(context, 'تاريخ الانتهاء يجب أن يكون بعد تاريخ البداية');
      return;
    }
    final s = widget.item ??
        SubscriptionItem(id: newId(), startDate: _start, endDate: _end);
    s
      ..name = name
      ..url = _url.text.trim()
      ..price = _price.text.trim()
      ..startDate = _start
      ..endDate = _end
      ..period = _period
      ..remindDays = _remind
      ..note = _note.text.trim()
      ..categoryId = _category;
    await Db.saveSub(s);
    await NotificationService.requestPermission();
    await NotificationService.scheduleFor(s);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final s = widget.item!;
    if (await confirmDelete(context, s.name)) {
      await NotificationService.cancelFor(s.id);
      await Db.subs.delete(s.id);
      if (mounted) Navigator.pop(context);
    }
  }

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 8, top: 4),
        child: Text(t,
            style: const TextStyle(
                color: AppColors.textSoft, fontWeight: FontWeight.w600)),
      );

  Widget _dateTile(String label, DateTime value, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style:
                      const TextStyle(color: AppColors.textSoft, fontSize: 12)),
              const SizedBox(height: 4),
              Row(
                children: [
                  const Icon(Icons.calendar_today_rounded,
                      size: 16, color: AppColors.blue),
                  const SizedBox(width: 6),
                  Text(formatDate(value),
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w700)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.item == null ? 'اشتراك جديد' : 'تعديل الاشتراك'),
        actions: [
          if (widget.item != null)
            IconButton(
              tooltip: 'حذف',
              icon: const Icon(Icons.delete_outline_rounded,
                  color: AppColors.danger),
              onPressed: _delete,
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _name,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'اسم الخدمة / الموقع',
              hintText: 'مثال: نتفليكس، استضافة، دومين',
              prefixIcon: Icon(Icons.apps_rounded),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _url,
            keyboardType: TextInputType.url,
            textDirection: TextDirection.ltr,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'الرابط (اختياري)',
              prefixIcon: Icon(Icons.link_rounded),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _price,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'السعر (اختياري)',
              hintText: 'مثال: 10 دولار',
              prefixIcon: Icon(Icons.payments_outlined),
            ),
          ),
          const SizedBox(height: 16),
          _label('مدة الاشتراك'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final p in SubPeriod.values)
                ChoiceChip(
                  label: Text(p.label),
                  selected: _period == p,
                  showCheckmark: false,
                  selectedColor: AppColors.blueLight,
                  backgroundColor: Colors.white,
                  side: BorderSide(
                      color: _period == p ? AppColors.blue : AppColors.border),
                  onSelected: (_) => setState(() {
                    _period = p;
                    _recalcEnd();
                  }),
                ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _dateTile('تاريخ البداية', _start, () async {
                final d = await _pick(_start);
                if (d != null) {
                  setState(() {
                    _start = d;
                    _recalcEnd();
                  });
                }
              }),
              const SizedBox(width: 10),
              _dateTile('تاريخ الانتهاء', _end, () async {
                final d = await _pick(_end);
                if (d != null) {
                  setState(() {
                    _end = d;
                    if (_end != addMonths(_start, _period.months)) {
                      _period = SubPeriod.custom;
                    }
                  });
                }
              }),
            ],
          ),
          const SizedBox(height: 16),
          _label('التذكير قبل الانتهاء'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final d in _remindOptions)
                ChoiceChip(
                  avatar: d == 0
                      ? null
                      : Icon(Icons.notifications_none_rounded,
                          size: 18,
                          color: _remind == d
                              ? AppColors.blue
                              : AppColors.textSoft),
                  label: Text(d == 0 ? 'بدون' : daysText(d)),
                  selected: _remind == d,
                  showCheckmark: false,
                  selectedColor: AppColors.blueLight,
                  backgroundColor: Colors.white,
                  side: BorderSide(
                      color: _remind == d ? AppColors.blue : AppColors.border),
                  onSelected: (_) => setState(() => _remind = d),
                ),
            ],
          ),
          const SizedBox(height: 6),
          const Text(
            'سيصلك أيضاً تنبيه في يوم الانتهاء نفسه.',
            style: TextStyle(color: AppColors.textSoft, fontSize: 12.5),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _note,
            minLines: 1,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'ملاحظة (اختياري)',
              prefixIcon: Icon(Icons.notes_rounded),
            ),
          ),
          const SizedBox(height: 16),
          CategoryPicker(
            value: _category,
            onChanged: (v) => setState(() => _category = v),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check_rounded),
            label: const Text('حفظ'),
          ),
        ],
      ),
    );
  }
}
