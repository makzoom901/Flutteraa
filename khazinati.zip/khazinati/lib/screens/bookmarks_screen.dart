import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../data/models.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/common.dart';
import 'settings_screen.dart';

class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key});

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  String _q = '';
  String? _cat;

  void _openForm([BookmarkItem? item]) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => BookmarkFormScreen(item: item, initialCategory: _cat)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المواقع المفضلة'),
        actions: const [SettingsButton()],
      ),
      floatingActionButton: FloatingActionButton(
        tooltip: 'إضافة موقع',
        onPressed: () => _openForm(),
        child: const Icon(Icons.add_rounded, size: 30),
      ),
      body: ListPage(
        searchHint: 'ابحث في المواقع المفضلة',
        onSearch: (v) => setState(() => _q = v),
        category: _cat,
        onCategory: (v) => setState(() => _cat = v),
        child: ListenableBuilder(
          listenable: Listenable.merge(
              [Db.bookmarks.listenable(), Db.categories.listenable()]),
          builder: (context, _) {
            final all = Db.allBookmarks();
            final items = applyFilter<BookmarkItem>(
                all, _q, _cat, (e, q) => e.matches(q), (e) => e.categoryId);
            if (items.isEmpty) {
              return all.isEmpty
                  ? const EmptyState(
                      icon: Icons.star_outline_rounded,
                      title: 'لا توجد مواقع مفضلة',
                      subtitle: 'احفظ مواقعك المهمة لتفتحها بضغطة واحدة',
                    )
                  : const EmptyState(
                      icon: Icons.search_off_rounded,
                      title: 'لا توجد نتائج',
                      subtitle: 'جرّب كلمة بحث أخرى',
                    );
            }
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 96),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final b = items[i];
                return ItemCard(
                  icon: Icons.public_rounded,
                  title: b.title,
                  subtitle: b.note.isNotEmpty
                      ? '${domainOf(b.url)} • ${b.note}'
                      : domainOf(b.url),
                  category: Db.category(b.categoryId),
                  onTap: () => openUrl(context, b.url),
                  onLongPress: () => _openForm(b),
                  trailing: PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert_rounded,
                        color: AppColors.textSoft),
                    onSelected: (v) async {
                      if (v == 'open') openUrl(context, b.url);
                      if (v == 'copy') {
                        copyText(context, normalizeUrl(b.url),
                            label: 'تم نسخ الرابط');
                      }
                      if (v == 'edit') _openForm(b);
                      if (v == 'delete' &&
                          await confirmDelete(context, b.title)) {
                        await Db.bookmarks.delete(b.id);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(
                          value: 'open',
                          child: ListTile(
                              leading: Icon(Icons.open_in_new_rounded),
                              title: Text('فتح'))),
                      PopupMenuItem(
                          value: 'copy',
                          child: ListTile(
                              leading: Icon(Icons.copy_rounded),
                              title: Text('نسخ الرابط'))),
                      PopupMenuItem(
                          value: 'edit',
                          child: ListTile(
                              leading: Icon(Icons.edit_outlined),
                              title: Text('تعديل'))),
                      PopupMenuItem(
                          value: 'delete',
                          child: ListTile(
                              leading: Icon(Icons.delete_outline_rounded,
                                  color: AppColors.danger),
                              title: Text('حذف'))),
                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class BookmarkFormScreen extends StatefulWidget {
  final BookmarkItem? item;
  final String? initialCategory;
  const BookmarkFormScreen({super.key, this.item, this.initialCategory});

  @override
  State<BookmarkFormScreen> createState() => _BookmarkFormScreenState();
}

class _BookmarkFormScreenState extends State<BookmarkFormScreen> {
  late final TextEditingController _title, _url, _note;
  String? _category;

  @override
  void initState() {
    super.initState();
    _title = TextEditingController(text: widget.item?.title ?? '');
    _url = TextEditingController(text: widget.item?.url ?? '');
    _note = TextEditingController(text: widget.item?.note ?? '');
    _category = widget.item?.categoryId ?? widget.initialCategory;
  }

  @override
  void dispose() {
    _title.dispose();
    _url.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final url = _url.text.trim();
    if (url.isEmpty) {
      showSnack(context, 'اكتب رابط الموقع');
      return;
    }
    var title = _title.text.trim();
    if (title.isEmpty) title = domainOf(url);
    final b = widget.item ?? BookmarkItem(id: newId());
    b
      ..title = title
      ..url = url
      ..note = _note.text.trim()
      ..categoryId = _category;
    await Db.saveBookmark(b);
    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final b = widget.item!;
    if (await confirmDelete(context, b.title)) {
      await Db.bookmarks.delete(b.id);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.item == null ? 'موقع مفضل جديد' : 'تعديل الموقع'),
        actions: [
          if (widget.item != null)
            IconButton(
              tooltip: 'حذف',
              icon: const Icon(Icons.delete_outline_rounded,
                  color: AppColors.danger),
              onPressed: _delete,
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _url,
            autofocus: widget.item == null,
            keyboardType: TextInputType.url,
            textDirection: TextDirection.ltr,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'رابط الموقع',
              hintText: 'example.com',
              prefixIcon: Icon(Icons.link_rounded),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _title,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'الاسم (اختياري)',
              prefixIcon: Icon(Icons.star_outline_rounded),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _note,
            minLines: 1,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: 'ملاحظة (اختياري)',
              prefixIcon: Icon(Icons.notes_rounded),
            ),
          ),
          const SizedBox(height: 16),
          CategoryPicker(
            value: _category,
            onChanged: (v) => setState(() => _category = v),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.check_rounded),
            label: const Text('حفظ'),
          ),
        ],
      ),
    );
  }
}
