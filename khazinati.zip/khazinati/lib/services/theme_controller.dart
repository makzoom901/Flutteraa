import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

import '../data/db.dart';
import '../theme.dart';

/// التبديل بين الوضع الفاتح والداكن
class ThemeController {
  static void load() {
    AppColors.dark = Db.darkMode;
    SystemChrome.setSystemUIOverlayStyle(systemUiStyle());
  }

  static Future<void> setDark(bool v) async {
    await Db.setDarkMode(v);
    apply(v);
  }

  /// تطبيق الوضع فوراً على كل الشاشات المفتوحة
  static void apply(bool v) {
    AppColors.dark = v;
    SystemChrome.setSystemUIOverlayStyle(systemUiStyle());
    final root = WidgetsBinding.instance.rootElement;
    if (root == null) return;
    void rebuild(Element e) {
      e.markNeedsBuild();
      e.visitChildren(rebuild);
    }

    root.visitChildren(rebuild);
  }
}
