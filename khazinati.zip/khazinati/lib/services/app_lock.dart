import 'package:flutter/widgets.dart';

/// حالة قفل التطبيق
class AppLock {
  static final locked = ValueNotifier<bool>(true);

  /// يُقفل التطبيق إذا بقي في الخلفية أكثر من هذه المدة
  static const backgroundTimeout = Duration(seconds: 30);

  static void lock() {
    FocusManager.instance.primaryFocus?.unfocus();
    locked.value = true;
  }

  static void unlock() => locked.value = false;
}
