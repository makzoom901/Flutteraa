import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../utils.dart';

/// جلب أيقونة الموقع (favicon) وحفظها مع العنصر
class IconService {
  static final _cache = <String, Uint8List>{};
  static final _running = <String>{};

  /// تحويل الأيقونة المحفوظة إلى صورة (مع ذاكرة مؤقتة)
  static Uint8List? bytes(String? b64) {
    if (b64 == null || b64.isEmpty) return null;
    return _cache.putIfAbsent(b64, () {
      try {
        return base64Decode(b64);
      } catch (_) {
        return Uint8List(0);
      }
    });
  }

  static Future<String?> _download(String domain) async {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 8)
      ..userAgent = 'Mozilla/5.0 (Linux; Android) Khazinati';
    try {
      final uri = Uri.https(
          'www.google.com', '/s2/favicons', {'domain': domain, 'sz': '128'});
      final req = await client.getUrl(uri);
      final res = await req.close().timeout(const Duration(seconds: 12));
      if (res.statusCode != 200) {
        await res.drain<void>();
        return null;
      }
      final data = await consolidateHttpClientResponseBytes(res)
          .timeout(const Duration(seconds: 12));
      if (data.length < 50 || data.length > 300000) return null;
      return base64Encode(data);
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }

  /// تحديث أيقونة عنصر واحد حسب رابطه
  static Future<void> refresh(Box box, String id) async {
    final key = '${box.name}/$id';
    if (_running.contains(key)) return;
    _running.add(key);
    try {
      final raw = box.get(id);
      if (raw is! Map) return;
      final domain = domainOf((raw['url'] ?? '') as String);
      final hasIcon = raw['icon'] != null;

      if (hasIcon && raw['iconDomain'] == domain) return; // محدّثة

      // الرابط تغيّر أو حُذف: امسح الأيقونة القديمة
      if (hasIcon) {
        final m = Map<String, dynamic>.from(raw)
          ..['icon'] = null
          ..['iconDomain'] = null;
        await box.put(id, m);
      }
      if (domain.isEmpty) return;

      final icon = await _download(domain);
      if (icon == null) return;

      final latest = box.get(id);
      if (latest is! Map) return; // حُذف أثناء التحميل
      if (domainOf((latest['url'] ?? '') as String) != domain) return;
      final m = Map<String, dynamic>.from(latest)
        ..['icon'] = icon
        ..['iconDomain'] = domain;
      await box.put(id, m);
    } finally {
      _running.remove(key);
    }
  }

  /// جلب الأيقونات الناقصة لكل العناصر (في الخلفية عند فتح التطبيق)
  static Future<void> refreshMissing() async {
    for (final box in [Db.passwords, Db.bookmarks, Db.subs]) {
      for (final k in box.keys.toList()) {
        final raw = box.get(k);
        if (raw is! Map) continue;
        final domain = domainOf((raw['url'] ?? '') as String);
        final ok = raw['icon'] != null && raw['iconDomain'] == domain;
        if (domain.isNotEmpty && !ok) {
          await refresh(box, k.toString());
        }
      }
    }
  }
}
