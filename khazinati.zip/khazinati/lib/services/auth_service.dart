import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:local_auth_android/local_auth_android.dart';

import '../data/db.dart';

/// الرمز السري + البصمة
class AuthService {
  static final _auth = LocalAuthentication();

  static const _pinHashKey = 'pin_hash';
  static const _pinSaltKey = 'pin_salt';
  static const _bioKey = 'bio_enabled';

  static const pinLength = 6;

  static Future<bool> hasPin() async =>
      (await secureStorage.read(key: _pinHashKey)) != null;

  /// الرمز لا يُحفظ أبداً، فقط بصمة (hash) مملّحة ومكرّرة
  static String _hash(String pin, String salt) {
    final input = utf8.encode('$salt:$pin');
    var digest = sha256.convert(input).bytes;
    for (var i = 0; i < 10000; i++) {
      digest = sha256.convert([...digest, ...input]).bytes;
    }
    return base64Encode(digest);
  }

  static Future<void> setPin(String pin) async {
    final r = Random.secure();
    final salt = base64Encode(List<int>.generate(16, (_) => r.nextInt(256)));
    await secureStorage.write(key: _pinSaltKey, value: salt);
    await secureStorage.write(key: _pinHashKey, value: _hash(pin, salt));
  }

  static Future<bool> checkPin(String pin) async {
    final salt = await secureStorage.read(key: _pinSaltKey);
    final hash = await secureStorage.read(key: _pinHashKey);
    if (salt == null || hash == null) return false;
    return _hash(pin, salt) == hash;
  }

  /// هل الجهاز يدعم البصمة وفيها بصمة مسجّلة؟
  static Future<bool> canUseBiometric() async {
    try {
      final supported = await _auth.isDeviceSupported();
      final can = await _auth.canCheckBiometrics;
      final list = await _auth.getAvailableBiometrics();
      return supported && can && list.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> bioEnabled() async =>
      (await secureStorage.read(key: _bioKey)) != 'false';

  static Future<void> setBioEnabled(bool v) =>
      secureStorage.write(key: _bioKey, value: v.toString());

  static Future<bool> authenticateBiometric() async {
    try {
      return await _auth.authenticate(
        localizedReason: 'استخدم البصمة لفتح خزنتي',
        authMessages: const [
          AndroidAuthMessages(
            signInTitle: 'خزنتي',
            biometricHint: 'ضع إصبعك على مستشعر البصمة',
            cancelButton: 'إلغاء',
          ),
        ],
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
    } on PlatformException {
      return false;
    }
  }
}
