import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../data/db.dart';
import '../data/models.dart';
import '../utils.dart';

/// تذكيرات انتهاء الاشتراكات
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'subscriptions_channel',
      'تذكير الاشتراكات',
      channelDescription: 'تنبيه قبل انتهاء اشتراكات المواقع والخدمات',
      importance: Importance.high,
      priority: Priority.high,
    ),
  );

  static Future<void> init() async {
    try {
      tzdata.initializeTimeZones();
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _plugin.initialize(const InitializationSettings(android: android));
    } catch (_) {}
  }

  static Future<void> requestPermission() async {
    try {
      await _plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    } catch (_) {}
  }

  /// رقم ثابت لكل اشتراك (رقمان: تذكير مسبق + يوم الانتهاء)
  static int _baseId(String subId) {
    var h = 0;
    for (final c in subId.codeUnits) {
      h = (h * 31 + c) & 0x3FFFFFFF;
    }
    return h * 2;
  }

  static Future<void> cancelFor(String subId) async {
    try {
      final base = _baseId(subId);
      await _plugin.cancel(base);
      await _plugin.cancel(base + 1);
    } catch (_) {}
  }

  static Future<void> scheduleFor(SubscriptionItem s) async {
    await cancelFor(s.id);
    final base = _baseId(s.id);
    final end = s.endDate;
    final name = s.name.isEmpty ? 'الخدمة' : s.name;

    if (s.remindDays > 0) {
      final remindAt =
          DateTime(end.year, end.month, end.day - s.remindDays, 10);
      await _schedule(
        base,
        remindAt,
        'اشتراك $name سينتهي قريباً',
        'متبقي ${daysText(s.remindDays)} على انتهاء الاشتراك',
      );
    }
    await _schedule(
      base + 1,
      DateTime(end.year, end.month, end.day, 10),
      'ينتهي اشتراك $name اليوم',
      'افتح خزنتي لتجديد الاشتراك',
    );
  }

  static Future<void> _schedule(
      int id, DateTime when, String title, String body) async {
    if (when.isBefore(DateTime.now())) return;
    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tz.TZDateTime.from(when, tz.UTC),
        _details,
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      );
    } catch (_) {}
  }

  static Future<void> cancelAll() async {
    try {
      await _plugin.cancelAll();
    } catch (_) {}
  }

  /// إعادة جدولة كل التذكيرات (عند فتح التطبيق)
  static Future<void> rescheduleAll() async {
    for (final s in Db.allSubs()) {
      await scheduleFor(s);
    }
  }
}
