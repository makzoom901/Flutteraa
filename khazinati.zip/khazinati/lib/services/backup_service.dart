import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart' as crypto;
import 'package:cryptography/cryptography.dart';

import '../data/db.dart';

class BackupException implements Exception {
  final String message;
  BackupException(this.message);
  @override
  String toString() => message;
}

/// نسخة احتياطية مشفّرة بكلمة مرور (AES-256-GCM + PBKDF2)
class BackupService {
  static const _iterations = 120000;
  static const _magic = 'khazinati-backup';

  /// PBKDF2-HMAC-SHA256 — يعمل في Isolate منفصل حتى لا تتجمّد الشاشة
  static Future<List<int>> _deriveKey(
      String password, List<int> salt, int iterations) {
    return Isolate.run(() {
      final hmac = crypto.Hmac(crypto.sha256, utf8.encode(password));
      var u = hmac.convert([...salt, 0, 0, 0, 1]).bytes;
      final t = List<int>.from(u);
      for (var i = 1; i < iterations; i++) {
        u = hmac.convert(u).bytes;
        for (var j = 0; j < t.length; j++) {
          t[j] ^= u[j];
        }
      }
      return t;
    });
  }

  static List<int> _random(int n) {
    final r = Random.secure();
    return List<int>.generate(n, (_) => r.nextInt(256));
  }

  /// إنشاء ملف النسخة الاحتياطية
  static Future<Uint8List> create(String password) async {
    final payload = {
      'createdAt': DateTime.now().toIso8601String(),
      'data': Db.exportAll(),
    };
    final clear = GZipCodec().encode(utf8.encode(jsonEncode(payload)));

    final salt = _random(16);
    final key = await _deriveKey(password, salt, _iterations);
    final aes = AesGcm.with256bits();
    final box = await aes.encrypt(
      clear,
      secretKey: SecretKey(key),
      nonce: aes.newNonce(),
    );

    final file = {
      'format': _magic,
      'version': 1,
      'kdf': 'pbkdf2-sha256',
      'iterations': _iterations,
      'salt': base64Encode(salt),
      'nonce': base64Encode(box.nonce),
      'mac': base64Encode(box.mac.bytes),
      'data': base64Encode(box.cipherText),
    };
    return Uint8List.fromList(utf8.encode(jsonEncode(file)));
  }

  /// قراءة وفك تشفير ملف النسخة الاحتياطية
  static Future<Map<String, dynamic>> read(
      List<int> fileBytes, String password) async {
    Map<String, dynamic> file;
    try {
      file = jsonDecode(utf8.decode(fileBytes)) as Map<String, dynamic>;
    } catch (_) {
      throw BackupException('الملف ليس نسخة احتياطية من خزنتي');
    }
    if (file['format'] != _magic) {
      throw BackupException('الملف ليس نسخة احتياطية من خزنتي');
    }

    final List<int> clear;
    try {
      final salt = base64Decode(file['salt'] as String);
      final iterations = (file['iterations'] as num).toInt();
      final key = await _deriveKey(password, salt, iterations);
      final box = SecretBox(
        base64Decode(file['data'] as String),
        nonce: base64Decode(file['nonce'] as String),
        mac: Mac(base64Decode(file['mac'] as String)),
      );
      clear = await AesGcm.with256bits().decrypt(box, secretKey: SecretKey(key));
    } on SecretBoxAuthenticationError {
      throw BackupException('كلمة مرور النسخة الاحتياطية غير صحيحة');
    } catch (_) {
      throw BackupException('الملف تالف أو غير صالح');
    }

    final payload =
        jsonDecode(utf8.decode(GZipCodec().decode(clear))) as Map<String, dynamic>;
    final data = payload['data'];
    if (data is! Map<String, dynamic>) {
      throw BackupException('الملف تالف أو غير صالح');
    }
    return data;
  }

  static String fileName() {
    final d = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    return 'khazinati-backup-${d.year}-${two(d.month)}-${two(d.day)}.json';
  }
}
