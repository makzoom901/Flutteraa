import 'package:flutter/material.dart';

import '../theme.dart';

/// نقاط الرمز السري
class PinDots extends StatelessWidget {
  final int length;
  final int filled;
  final bool error;
  const PinDots(
      {super.key, required this.length, required this.filled, this.error = false});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          for (var i = 0; i < length; i++)
            AnimatedContainer(
              duration: const Duration(milliseconds: 120),
              margin: const EdgeInsets.symmetric(horizontal: 8),
              width: 16,
              height: 16,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: error
                    ? AppColors.danger
                    : (i < filled ? AppColors.blue : Colors.transparent),
                border: Border.all(
                  color: error
                      ? AppColors.danger
                      : (i < filled ? AppColors.blue : AppColors.textSoft),
                  width: 2,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// لوحة الأرقام
class PinPad extends StatelessWidget {
  final ValueChanged<String> onDigit;
  final VoidCallback onBackspace;
  final VoidCallback? onBiometric;
  final bool enabled;

  const PinPad({
    super.key,
    required this.onDigit,
    required this.onBackspace,
    this.onBiometric,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    Widget digit(String d) => _Key(
          onTap: enabled ? () => onDigit(d) : null,
          child: Text(d,
              style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w600,
                  color: AppColors.text)),
        );

    final rows = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
    ];

    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final r in rows)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [for (final d in r) digit(d)],
            ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              onBiometric != null
                  ? _Key(
                      onTap: enabled ? onBiometric : null,
                      child: const Icon(Icons.fingerprint_rounded,
                          size: 38, color: AppColors.blue),
                    )
                  : const SizedBox(width: 92, height: 80),
              digit('0'),
              _Key(
                onTap: enabled ? onBackspace : null,
                child: const Icon(Icons.backspace_outlined,
                    size: 26, color: AppColors.textSoft),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Key extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  const _Key({required this.child, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Material(
        color: Colors.white,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(width: 68, height: 68, child: Center(child: child)),
        ),
      ),
    );
  }
}
