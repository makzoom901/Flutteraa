import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/db.dart';
import '../data/models.dart';
import '../services/icon_service.dart';
import '../theme.dart';
import 'category_editor.dart';

/// حقل البحث
class SearchField extends StatelessWidget {
  final String hint;
  final ValueChanged<String> onChanged;
  const SearchField({super.key, required this.hint, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: TextField(
        onChanged: (v) => onChanged(v.trim().toLowerCase()),
        textInputAction: TextInputAction.search,
        decoration: InputDecoration(
          hintText: hint,
          prefixIcon: const Icon(Icons.search_rounded),
          contentPadding: const EdgeInsets.symmetric(vertical: 12),
        ),
      ),
    );
  }
}

/// شريط فلترة التصنيفات (الكل، شخصي، عمل...)
class CategoryFilterBar extends StatelessWidget {
  final String? selected; // null = الكل
  final ValueChanged<String?> onChanged;
  const CategoryFilterBar(
      {super.key, required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: Db.categories.listenable(),
      builder: (context, _, __) {
        final cats = Db.allCategories();
        return SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              _chip('الكل', AppColors.blue, selected == null,
                  () => onChanged(null)),
              for (final c in cats)
                _chip(c.name, c.colorValue, selected == c.id,
                    () => onChanged(c.id)),
            ],
          ),
        );
      },
    );
  }

  Widget _chip(String label, Color color, bool active, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: Material(
        color: active ? color : AppColors.card,
        shape: StadiumBorder(
          side: BorderSide(color: active ? color : AppColors.border),
        ),
        child: InkWell(
          customBorder: const StadiumBorder(),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!active) ...[
                  Container(
                    width: 9,
                    height: 9,
                    decoration:
                        BoxDecoration(color: color, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                ],
                Text(
                  label,
                  style: TextStyle(
                    color: active ? Colors.white : AppColors.text,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// اختيار التصنيف داخل النماذج
class CategoryPicker extends StatelessWidget {
  final String? value;
  final ValueChanged<String?> onChanged;
  const CategoryPicker({super.key, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: Db.categories.listenable(),
      builder: (context, _, __) {
        final cats = Db.allCategories();
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('التصنيف',
                style: TextStyle(
                    color: AppColors.textSoft, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in cats)
                  ChoiceChip(
                    label: Text(c.name),
                    selected: value == c.id,
                    onSelected: (s) => onChanged(s ? c.id : null),
                    avatar: CircleAvatar(backgroundColor: c.colorValue, radius: 6),
                    selectedColor: c.colorValue.withValues(alpha: 0.18),
                    showCheckmark: false,
                    side: BorderSide(
                        color: value == c.id ? c.colorValue : AppColors.border),
                    backgroundColor: AppColors.card,
                  ),
                ActionChip(
                  avatar: const Icon(Icons.add_rounded, size: 18),
                  label: const Text('تصنيف جديد'),
                  backgroundColor: AppColors.card,
                  side: BorderSide(color: AppColors.border),
                  onPressed: () async {
                    final c = await showCategoryEditor(context);
                    if (c != null) onChanged(c.id);
                  },
                ),
              ],
            ),
          ],
        );
      },
    );
  }
}

/// شارة التصنيف الصغيرة
class CategoryTag extends StatelessWidget {
  final ItemCategory? category;
  const CategoryTag({super.key, this.category});

  @override
  Widget build(BuildContext context) {
    final c = category;
    if (c == null) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: c.colorValue.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        c.name,
        style: TextStyle(
            color: c.colorValue, fontSize: 11.5, fontWeight: FontWeight.w700),
      ),
    );
  }
}

/// بطاقة عنصر موحّدة لكل القوائم
class ItemCard extends StatelessWidget {
  final IconData icon;
  final String? siteIcon; // شعار الموقع (base64)
  final String title;
  final String? subtitle;
  final ItemCategory? category;
  final Widget? trailing;
  final Widget? extra;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;

  const ItemCard({
    super.key,
    required this.icon,
    this.siteIcon,
    required this.title,
    this.subtitle,
    this.category,
    this.trailing,
    this.extra,
    this.onTap,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final color = category?.colorValue ?? AppColors.textSoft;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 4, 12),
          child: Row(
            children: [
              SiteAvatar(icon: icon, siteIcon: siteIcon, color: color),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(
                          child: Text(
                            title.isEmpty ? 'بدون عنوان' : title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w700),
                          ),
                        ),
                        const SizedBox(width: 6),
                        CategoryTag(category: category),
                      ],
                    ),
                    if (subtitle != null && subtitle!.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(
                        subtitle!,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: AppColors.textSoft, fontSize: 13.5),
                      ),
                    ],
                    if (extra != null) ...[const SizedBox(height: 6), extra!],
                  ],
                ),
              ),
              if (trailing != null) trailing!,
            ],
          ),
        ),
      ),
    );
  }
}

/// شاشة فارغة
class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const EmptyState(
      {super.key,
      required this.icon,
      required this.title,
      required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                color: AppColors.blueLight,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 42, color: AppColors.blue),
            ),
            const SizedBox(height: 16),
            Text(title,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(subtitle,
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.textSoft)),
          ],
        ),
      ),
    );
  }
}

/// تأكيد الحذف
Future<bool> confirmDelete(BuildContext context, String what) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('تأكيد الحذف'),
      content: Text('هل تريد حذف "$what"؟ لا يمكن التراجع.'),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('إلغاء')),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          style: TextButton.styleFrom(foregroundColor: AppColors.danger),
          child: const Text('حذف'),
        ),
      ],
    ),
  );
  return ok ?? false;
}

/// فلترة عامة حسب البحث والتصنيف
List<T> applyFilter<T>(List<T> items, String query, String? categoryId,
    bool Function(T, String) matches, String? Function(T) catOf) {
  return items.where((e) {
    if (categoryId != null && catOf(e) != categoryId) return false;
    if (query.isNotEmpty && !matches(e, query)) return false;
    return true;
  }).toList();
}

/// غلاف شاشة القائمة: بحث + تصنيفات + محتوى
class ListPage extends StatelessWidget {
  final String searchHint;
  final ValueChanged<String> onSearch;
  final String? category;
  final ValueChanged<String?> onCategory;
  final Widget? header;
  final Widget child;

  const ListPage({
    super.key,
    required this.searchHint,
    required this.onSearch,
    required this.category,
    required this.onCategory,
    required this.child,
    this.header,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SearchField(hint: searchHint, onChanged: onSearch),
        CategoryFilterBar(selected: category, onChanged: onCategory),
        if (header != null) header!,
        const SizedBox(height: 8),
        Expanded(child: child),
      ],
    );
  }
}

/// أيقونة العنصر: شعار الموقع إن وُجد، وإلا أيقونة عادية بلون التصنيف
class SiteAvatar extends StatelessWidget {
  final IconData icon;
  final String? siteIcon;
  final Color color;
  final double size;

  const SiteAvatar({
    super.key,
    required this.icon,
    required this.color,
    this.siteIcon,
    this.size = 46,
  });

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(size * 0.3),
      ),
      child: Icon(icon, color: color, size: size * 0.52),
    );

    final bytes = IconService.bytes(siteIcon);
    if (bytes == null || bytes.isEmpty) return fallback;

    return Container(
      width: size,
      height: size,
      padding: EdgeInsets.all(size * 0.2),
      decoration: BoxDecoration(
        color: Colors.white, // خلفية بيضاء حتى تظهر الشعارات بوضوح في الوضع الداكن
        borderRadius: BorderRadius.circular(size * 0.3),
        border: Border.all(color: AppColors.border),
      ),
      child: Image.memory(
        bytes,
        fit: BoxFit.contain,
        gaplessPlayback: true,
        filterQuality: FilterQuality.medium,
        errorBuilder: (_, __, ___) =>
            Icon(icon, color: color, size: size * 0.5),
      ),
    );
  }
}
