import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

/// "يوم واحد" / "يومان" / "5 أيام" / "15 يوماً"
String daysText(int n) {
  n = n.abs();
  if (n == 0) return 'اليوم';
  if (n == 1) return 'يوم واحد';
  if (n == 2) return 'يومان';
  if (n <= 10) return '$n أيام';
  return '$n يوماً';
}

String formatDate(DateTime d) {
  String two(int v) => v.toString().padLeft(2, '0');
  return '${two(d.day)}/${two(d.month)}/${d.year}';
}

String normalizeUrl(String url) {
  final u = url.trim();
  if (u.isEmpty) return u;
  if (u.startsWith('http://') || u.startsWith('https://')) return u;
  return 'https://$u';
}

/// اسم الموقع المختصر من الرابط
String domainOf(String url) {
  final uri = Uri.tryParse(normalizeUrl(url));
  final host = uri?.host ?? '';
  return host.startsWith('www.') ? host.substring(4) : host;
}

Future<void> openUrl(BuildContext context, String url) async {
  final u = normalizeUrl(url);
  if (u.isEmpty) return;
  var ok = false;
  try {
    ok = await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
  } catch (_) {
    ok = false;
  }
  if (!ok && context.mounted) {
    showSnack(context, 'تعذّر فتح الرابط');
  }
}

void showSnack(BuildContext context, String text) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(text)));
}

Timer? _clipTimer;

/// نسخ إلى الحافظة — وكلمات المرور تُمسح تلقائياً بعد 30 ثانية
Future<void> copyText(BuildContext context, String text,
    {String label = 'تم النسخ', bool sensitive = false}) async {
  if (text.isEmpty) return;
  await Clipboard.setData(ClipboardData(text: text));
  if (context.mounted) {
    showSnack(context, sensitive ? '$label • ستُمسح بعد 30 ثانية' : label);
  }
  if (sensitive) {
    _clipTimer?.cancel();
    _clipTimer = Timer(const Duration(seconds: 30), () async {
      final current = await Clipboard.getData(Clipboard.kTextPlain);
      if (current?.text == text) {
        await Clipboard.setData(const ClipboardData(text: ''));
      }
    });
  }
}

/// مولّد كلمات مرور قوية
String generatePassword({int length = 16, bool symbols = true}) {
  const lower = 'abcdefghijkmnopqrstuvwxyz';
  const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  const digits = '23456789';
  const sym = '!@#\$%&*?-_+=';
  final pool = lower + upper + digits + (symbols ? sym : '');
  final r = Random.secure();
  final chars = <String>[
    lower[r.nextInt(lower.length)],
    upper[r.nextInt(upper.length)],
    digits[r.nextInt(digits.length)],
    if (symbols) sym[r.nextInt(sym.length)],
  ];
  while (chars.length < length) {
    chars.add(pool[r.nextInt(pool.length)]);
  }
  chars.shuffle(r);
  return chars.join();
}

/// قوة كلمة المرور من 0 إلى 4
int passwordStrength(String p) {
  if (p.isEmpty) return 0;
  var score = 0;
  if (p.length >= 8) score++;
  if (p.length >= 12) score++;
  if (RegExp(r'[A-Z]').hasMatch(p) && RegExp(r'[a-z]').hasMatch(p)) score++;
  if (RegExp(r'[0-9]').hasMatch(p) && RegExp(r'[^A-Za-z0-9]').hasMatch(p)) {
    score++;
  }
  return score.clamp(0, 4);
}
