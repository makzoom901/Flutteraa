// يجهّز مجلد android بعد أمر flutter create:
// - البصمة (FlutterFragmentActivity)
// - منع تصوير الشاشة (FLAG_SECURE)
// - صلاحيات وتذكيرات الإشعارات
// - اسم التطبيق بالعربي ومنع النسخ الاحتياطي السحابي
//
// الاستخدام:  dart run tool/setup_android.dart
import 'dart:io';

void main() {
  _patchMainActivity();
  _patchManifest();
  _patchGradle();
  final test = File('test/widget_test.dart');
  if (test.existsSync()) test.deleteSync();
  stdout.writeln('✅ تم تجهيز مشروع أندرويد بنجاح');
}

Never _fail(String msg) {
  stderr.writeln('❌ $msg');
  exit(1);
}

void _patchMainActivity() {
  final dir = Directory('android/app/src/main');
  if (!dir.existsSync()) {
    _fail('لم يتم العثور على مجلد android. شغّل أولاً: flutter create --platforms=android .');
  }
  final files = dir
      .listSync(recursive: true)
      .whereType<File>()
      .where((f) =>
          f.path.endsWith('MainActivity.kt') ||
          f.path.endsWith('MainActivity.java'))
      .toList();
  if (files.isEmpty) _fail('لم يتم العثور على MainActivity');

  final file = files.first;
  final pkg = RegExp(r'^package\s+([\w.]+)', multiLine: true)
      .firstMatch(file.readAsStringSync())
      ?.group(1);
  if (pkg == null) _fail('لم يتم العثور على اسم الحزمة في MainActivity');

  final kt = File(file.path.replaceAll(RegExp(r'\.java$'), '.kt'));
  if (file.path.endsWith('.java')) file.deleteSync();
  kt.writeAsStringSync('''package $pkg

import android.os.Bundle
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity : FlutterFragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // منع تصوير الشاشة وإخفاء المحتوى في قائمة التطبيقات الأخيرة
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }
}
''');
}

void _patchManifest() {
  final f = File('android/app/src/main/AndroidManifest.xml');
  var s = f.readAsStringSync();
  if (s.contains('USE_BIOMETRIC')) return; // تم التجهيز مسبقاً

  const perms = '''
    <uses-permission android:name="android.permission.USE_BIOMETRIC"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
''';
  s = s.replaceFirstMapped(
      RegExp(r'<manifest[^>]*>'), (m) => '${m.group(0)}\n$perms');

  // اسم التطبيق + منع النسخ الاحتياطي
  s = s.replaceFirst(RegExp(r'android:label="[^"]*"'),
      'android:label="خزنتي"\n        android:allowBackup="false"\n        android:fullBackupContent="false"');

  const receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
    </application>''';
  s = s.replaceFirst('</application>', receivers);

  const urlQueries = '''
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="http" />
        </intent>''';
  if (s.contains('<queries>')) {
    s = s.replaceFirst('<queries>', '<queries>$urlQueries');
  } else {
    s = s.replaceFirst(
        '</manifest>', '    <queries>$urlQueries\n    </queries>\n</manifest>');
  }
  f.writeAsStringSync(s);
}

void _patchGradle() {
  final kts = File('android/app/build.gradle.kts');
  final groovy = File('android/app/build.gradle');
  final isKts = kts.existsSync();
  final f = isKts ? kts : groovy;
  if (!f.existsSync()) _fail('لم يتم العثور على android/app/build.gradle');
  var s = f.readAsStringSync();
  if (s.contains('desugar_jdk_libs')) return;

  // دعم مكتبات Java الحديثة (مطلوب لمكتبة الإشعارات)
  s = s.replaceFirst(
    RegExp(r'compileOptions\s*\{'),
    isKts
        ? 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true'
        : 'compileOptions {\n        coreLibraryDesugaringEnabled true',
  );

  // أقل إصدار أندرويد 6.0
  s = s.replaceFirst(
    RegExp(r'minSdk(Version)?\s*=?\s*flutter\.minSdkVersion'),
    isKts ? 'minSdk = 23' : 'minSdkVersion 23',
  );

  s += isKts
      ? '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
      : '\ndependencies {\n    coreLibraryDesugaring "com.android.tools:desugar_jdk_libs:2.1.4"\n}\n';
  f.writeAsStringSync(s);
}
