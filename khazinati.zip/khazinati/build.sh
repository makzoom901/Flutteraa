#!/usr/bin/env bash
set -e
echo "=== بناء تطبيق خزنتي ==="
if [ ! -d android ]; then
  flutter create --platforms=android --org com.khazinati --project-name khazinati .
  flutter pub get
  dart run tool/setup_android.dart
  dart run flutter_launcher_icons
else
  flutter pub get
fi
flutter build apk --release
echo
echo "تم! الملف: build/app/outputs/flutter-apk/app-release.apk"
